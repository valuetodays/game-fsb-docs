package lwjgui.geometry;

public interface Resizable {
	public boolean isResizeable();
}
