package lwjgui.gl;

import lwjgui.scene.Context;

public interface Renderer {
	void render(Context context);
}