package lwjgui.style;

import lwjgui.collections.ObservableList;

public interface StyleBoxShadow {
	public ObservableList<BoxShadow> getBoxShadowList();
}
