package lwjgui.style;

public enum BorderStyle {
	NONE,
	SOLID,
}
