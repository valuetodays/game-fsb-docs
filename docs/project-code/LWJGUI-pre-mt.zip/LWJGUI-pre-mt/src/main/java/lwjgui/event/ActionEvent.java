package lwjgui.event;

public class ActionEvent extends Event {

}
