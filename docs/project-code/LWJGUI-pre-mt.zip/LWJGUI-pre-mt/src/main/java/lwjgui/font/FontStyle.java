package lwjgui.font;

public enum FontStyle {
	REGULAR, BOLD, LIGHT, ITALIC;
}