package lwjgui.event;

public interface ElementCallback<E> {
	
	public void onEvent(E object);
}
