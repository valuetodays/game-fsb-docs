package lwjgui.event;

import lwjgui.scene.control.Tab;

public class TabDragEvent extends Event {
	
	public TabDragEvent( Tab tab ) {
		
	}

}
