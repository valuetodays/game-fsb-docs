package lwjgui.scene.layout;

public interface Gappable {
	public float getVgap();
	
	public float getHgap();
	
	public void setVgap(float spacing);
	
	public void setHgap(float spacing);
}
