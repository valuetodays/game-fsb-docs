package lwjgui.style;

public interface StyleBackground {
	public Background getBackground();
	public void setBackground(Background color);
}
