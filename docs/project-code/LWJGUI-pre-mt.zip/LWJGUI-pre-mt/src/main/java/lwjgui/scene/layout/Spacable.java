package lwjgui.scene.layout;

public interface Spacable {
	public double getSpacing();
	public void setSpacing(double spacing);
}
