package lwjgui.scene.layout;


public enum Priority {
	ALWAYS,
	NEVER;
}
