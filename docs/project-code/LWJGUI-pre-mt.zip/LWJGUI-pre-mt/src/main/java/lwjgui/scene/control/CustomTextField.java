package lwjgui.scene.control;

import lwjgui.scene.Node;

public class CustomTextField extends CustomTextFieldBase {

	@Override
	public void setLeftNode(Node node) {
		super.setLeftNode(node);
	}
	
	@Override
	public void setRightNode(Node node) {
		super.setRightNode(node);
	}

	@Override
	public Node getLeftNode() {
		return super.getLeftNode();
	}
	
	@Override
	public Node getRightNode() {
		return super.getRightNode();
	}
}
