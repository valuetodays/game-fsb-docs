package com.legend.apu;

/**
 * @author Legend
 * @data by on 20-5-2.
 * @description
 */
public interface SweepListener {
    void onSweep();
}
