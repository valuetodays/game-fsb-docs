# build

- install mysys2 https://www.msys2.org/
- install plugins in mysys2
  - pacman -S --noconfirm mingw-w64-x86_64-pkg-config mingw-w64-x86_64-gcc mingw-w64-x86_64-portaudio

```bash
CGO_ENABLED=1 /d/ws/apps/go/bin/go build .
```


