export interface IDMA {
  copy(cpuBusAddr: number): void;
}
