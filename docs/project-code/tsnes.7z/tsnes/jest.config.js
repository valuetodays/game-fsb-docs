module.exports = {
  preset: 'ts-jest',
  roots: [
    'src'
  ],
  testEnvironment: 'node',
  verbose: true
};
