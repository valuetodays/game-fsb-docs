package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * NOP指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class NOP extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public NOP(M6502 cpu) {
        super(cpu);
        this.setAliasName("NOP");
        this.setCode("NOP");
        this.addMachineCodeByArray(new String[]{
                "EA"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("EA", 1, 2),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        //什么都不做。。。。
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
