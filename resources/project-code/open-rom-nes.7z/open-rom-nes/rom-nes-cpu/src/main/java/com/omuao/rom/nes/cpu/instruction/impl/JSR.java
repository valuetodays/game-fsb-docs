package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * JSR指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class JSR extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public JSR(M6502 cpu) {
        super(cpu);
        this.setAliasName("JSR");
        this.setCode("JSR");
        this.addMachineCodeByArray(new String[]{
                "20"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.absolute("20", 3, 6),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int pc = cpu.getPC().getValue();
        pc--;
        cpu.push((pc >> 8) & 0xff);
        cpu.push(pc & 0xff);
        cpu.getPC().setValue(this.addressModeValue());
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
