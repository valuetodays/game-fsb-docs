package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * TXS指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class TXS extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public TXS(M6502 cpu) {
        super(cpu);
        this.setAliasName("TXS");
        this.setCode("TXS");
        this.addMachineCodeByArray(new String[]{
                "9A"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("9A", 1, 2),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = cpu.getXR().getValue() & 0xff;
        cpu.getSP().setValue(src);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
