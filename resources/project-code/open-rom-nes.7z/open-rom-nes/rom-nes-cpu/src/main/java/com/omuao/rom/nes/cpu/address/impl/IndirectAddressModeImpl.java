package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.common.model.memory.Memory;
import com.omuao.rom.nes.cpu.M6502;

/**
 * 间接寻址 3Byte
 * <p>
 * 指令码  地址低位  地址高位
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class IndirectAddressModeImpl extends M6502AddressMode {

    public IndirectAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int pc = cpu.getPC().getValue();
        int address = cpu.load2Byte(pc + 2);
        Memory memory = cpu.getMemory();

        //读取RAM 两字节内容
        if (address < 0x1fff) {
            address =
                    memory.read(address) +
                            (memory.read((address & 0xff00) | (((address & 0xff) + 1) & 0xff)) << 8);
        } else {
            //TODO Mapper Read
        }
        return address;
    }

}
