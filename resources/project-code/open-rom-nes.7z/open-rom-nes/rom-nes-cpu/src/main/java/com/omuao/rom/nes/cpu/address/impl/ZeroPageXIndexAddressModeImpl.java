package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 零页寻址 X寄存器索引变址 2Byte
 * <p>
 * 指令码  地址
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class ZeroPageXIndexAddressModeImpl extends M6502AddressMode {

    public ZeroPageXIndexAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int pc = cpu.getPC().getValue();
        int xr = cpu.getXR().getValue();
        int address = (cpu.load(pc + 1) + xr) & 0xff;
        return address;
    }

}
