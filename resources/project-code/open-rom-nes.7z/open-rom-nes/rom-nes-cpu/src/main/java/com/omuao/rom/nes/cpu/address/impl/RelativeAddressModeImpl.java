package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 相对寻址 2Byte
 * <p>
 * 指令码  偏移量
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class RelativeAddressModeImpl extends M6502AddressMode {

    public RelativeAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {

        int pc = cpu.getPC().getValue();

        int address = cpu.load(pc + 2);

        if (address < 0x80) {
            address += pc;
        } else {
            address += pc - 256;
        }

        return address;
    }

}
