package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * BRK指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class BRK extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public BRK(M6502 cpu) {
        super(cpu);
        this.setAliasName("BRK");
        this.setCode("BRK");
        this.addMachineCodeByArray(new String[]{
                "00"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("00", 1, 7),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int pc = cpu.getPC().getValue(); //程序计数器
        pc++;
        cpu.push((pc >> 8) & 0xff);
        cpu.push(pc & 0xff);
        cpu.getSR().initStatus(SR.BREAK_COMMAND, true);
        cpu.push(cpu.getSR().getValue());
        cpu.getSR().initStatus(SR.INTERRUPT_DISABLE, true);
        //INT 中断方式
        pc = (cpu.load(0xFFFE) | (cpu.load(0xFFFF) << 8));
        cpu.getPC().setValue(pc);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
