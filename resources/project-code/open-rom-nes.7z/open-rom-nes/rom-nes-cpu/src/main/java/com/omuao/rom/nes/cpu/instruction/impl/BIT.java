package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * BIT指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class BIT extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public BIT(M6502 cpu) {
        super(cpu);
        this.setAliasName("BIT");
        this.setCode("BIT");
        this.addMachineCodeByArray(new String[]{
                "24", "2C"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.zeroPage("24", 2, 3),
                M6502InstructionInfoBuilder.absolute("2C", 3, 4),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        cpu.getSR().initStatus(SR.NEGATIVE, src < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.OVERFLOW, (0x40 & src) > 0);//计算结果溢出设置
        cpu.getSR().initStatus(SR.ZERO, (src & ac) == 0); //计算结果为0时设置
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
