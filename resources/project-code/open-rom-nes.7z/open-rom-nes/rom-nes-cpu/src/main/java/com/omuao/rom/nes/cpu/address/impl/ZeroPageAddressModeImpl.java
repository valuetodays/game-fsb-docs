package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 零页寻址 2Byte
 * <p>
 * 指令码  地址
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class ZeroPageAddressModeImpl extends M6502AddressMode {

    public ZeroPageAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int address = cpu.getPC().getValue() + 1;
        if (address < 0x100) {
            return cpu.load(address);
        }
        return -1;
    }

}
