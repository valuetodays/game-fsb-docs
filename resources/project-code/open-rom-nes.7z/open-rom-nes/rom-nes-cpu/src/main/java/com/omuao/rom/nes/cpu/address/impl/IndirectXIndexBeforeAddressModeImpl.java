package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 先X 寄存器 索引，然后再间接寻址 3Byte
 * <p>
 * 指令码  地址低位  地址高位
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class IndirectXIndexBeforeAddressModeImpl extends M6502AddressMode {

    public IndirectXIndexBeforeAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int pc = cpu.getPC().getValue();
        int xr = cpu.getXR().getValue();
        int address = cpu.load(pc + 2);
        /*if ((address & 0xff00) != ((address + xr) & 0xff00)) {
            clockAdd = 1;//寻址周期
        }*/
        address += xr;
        address &= 0xff;
        address = cpu.load2Byte(address);
        return address;
    }

}

