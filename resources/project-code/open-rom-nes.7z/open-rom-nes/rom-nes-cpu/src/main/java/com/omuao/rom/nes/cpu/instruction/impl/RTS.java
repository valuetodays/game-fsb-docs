package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * RTS指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class RTS extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public RTS(M6502 cpu) {
        super(cpu);
        this.setAliasName("RTS");
        this.setCode("RTS");
        this.addMachineCodeByArray(new String[]{
                "60"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("60", 1, 6),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = cpu.pull();
        src += (cpu.pull() << 8) + 1;
        cpu.getPC().setValue(src);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
