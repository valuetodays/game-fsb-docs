package com.omuao.rom.nes.cpu;

import com.omuao.rom.nes.common.exception.MemoryIndexOutOfBoundsException;
import com.omuao.rom.nes.common.model.address.AddressMode;
import com.omuao.rom.nes.common.model.cpu.CPU;
import com.omuao.rom.nes.common.model.device.DeviceInfo;
import com.omuao.rom.nes.common.model.device.DeviceType;
import com.omuao.rom.nes.common.model.instruction.InstructionSet;
import com.omuao.rom.nes.common.model.memory.Memory;
import com.omuao.rom.nes.common.model.register.Register;
import com.omuao.rom.nes.common.model.register.StatusRegister;
import com.omuao.rom.nes.cpu.address.impl.*;
import com.omuao.rom.nes.cpu.instruction.impl.M6502InstructionSetImpl;
import com.omuao.rom.nes.cpu.memory.impl.CPUMemoryImpl;
import com.omuao.rom.nes.cpu.register.impl.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 6502 CPU 抽象实现
 * <p>
 * CPU Memory Map
 * --------------------------------------- $10000
 * Upper Bank of Cartridge ROM            卡带的上层ROM
 * --------------------------------------- $C000
 * Lower Bank of Cartridge ROM            卡带的下层ROM
 * --------------------------------------- $8000
 * Cartridge RAM (may be battery-backed)  卡带的RAM（可能有电池支持）
 * --------------------------------------- $6000
 * Expansion Modules                      扩充的模块
 * --------------------------------------- $5000
 * Input/Output                           输入/输出
 * --------------------------------------- $2000
 * 2kB Internal RAM, mirrored 4 times     2KB的内部RAM，做4次镜象
 * --------------------------------------- $0000
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public abstract class M6502 implements CPU {

    /**
     * 默认内存支持映射大小
     */
    public static final int DEFAULT_MEMORY_SIZE = 0x10000;

    /**
     * CPU内部RAM大小
     */
    public static final int DEFAULT_INTERNAL_RAM_SIZE = 0x2000;

    /**
     * 指令集
     */
    private List<InstructionSet> instructionSet;

    /**
     * 内存
     */
    private Memory memory;

    /**
     * 当前执行程序计数器
     */
    private Integer currentPC;

    /**
     * 6502寻址方式
     */
    private Map<String, AddressMode> addressModeMap;

    /**
     * 6502寄存器
     */
    private List<Register> registers;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备编码
     */
    private String deviceCode;

    /**
     * 设备类型
     */
    private DeviceType deviceType;

    /**
     * 设备信息
     */
    private List<DeviceInfo> deviceContents;

    public M6502() {
        initCPUInfo();
        initRegister();
        initMemory();
        initInstruction();
        initAddressMode();
    }

    protected void initCPUInfo() {
        this.currentPC = 0;
        this.deviceName = "MOS 6502";
        this.deviceCode = "MOS 6502";
        this.deviceType = DeviceType.PROCESSOR;
        this.deviceContents = new ArrayList<>();
    }

    protected void initAddressMode() {
        addressModeMap = new HashMap<>();
        addressModeMap.put(M6502AddressMode.ABSOLUTE, new AbsoluteAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ABSOLUTE_X, new AbsoluteXIndexAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ABSOLUTE_Y, new AbsoluteYIndexAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ACCUMULATOR, new AccumulatorAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.IMMEDIATELY, new ImmediatelyAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.IMPLICIT, new ImplicitAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.INDIRECT, new IndirectAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.INDIRECT_XB, new IndirectXIndexBeforeAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.INDIRECT_YA, new IndirectYIndexAfterAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.RELATIVE, new RelativeAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ZERO_PAGE, new ZeroPageAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ZERO_PAGE_X, new ZeroPageXIndexAddressModeImpl(this));
        addressModeMap.put(M6502AddressMode.ZERO_PAGE_Y, new ZeroPageYIndexAddressModeImpl(this));
    }

    /**
     * 初始化指令集
     */
    protected void initInstruction() {
        this.instructionSet = new ArrayList<>();
        this.instructionSet.add(new M6502InstructionSetImpl(this));
    }

    /**
     * 初始化CPU 内存 工作区域
     */
    protected void initMemory() {
        memory = new CPUMemoryImpl(new int[M6502.DEFAULT_INTERNAL_RAM_SIZE]);
        memory.setReadable(true);
        memory.setWritable(true);
    }

    /**
     * 初始化 CPU 的寄存器
     */
    protected void initRegister() {
        List<Register> registers = new ArrayList<>();
        registers.add(new AR());
        registers.add(new PC());
        registers.add(new SP());
        registers.add(new SR());
        registers.add(new XR());
        registers.add(new YR());
        this.setRegisters(registers);
    }

    @Override
    public List<InstructionSet> getInstructionSet() {
        return this.instructionSet;
    }

    @Override
    public void setInstructionSet(List<InstructionSet> instructionSet) {
        this.instructionSet = instructionSet;
    }

    @Override
    public Memory getMemory() {
        return memory;
    }

    @Override
    public void setMemory(Memory memory) {
        this.memory = memory;
    }

    /**
     * CPU 栈 push操作
     * <p>
     * $0x0100 - $0x01ff  = 256字节的栈操作
     */
    public abstract void push(int value);

    /**
     * CPU 栈 pull操作
     * <p>
     * $0x0100 - $0x01ff  = 256字节的栈操作
     *
     * @return
     */
    public abstract int pull();

    /**
     * 读取内存 1字节(8Bit)
     *
     * @param address 地址
     * @return 值
     */
    public int load(int address) {
        if (address >= M6502.DEFAULT_INTERNAL_RAM_SIZE) {
            throw new MemoryIndexOutOfBoundsException("CPU 最大支持寻址范围为0 - 0xffff!");
        }

        if (address < 0x2000) {
            return this.memory.read(address & 0x7ff);
        } else {
            //TODO Mapper Read
            return 0;
        }
    }

    /**
     * 读取2字节（16Bit）
     *
     * @param address 地址
     * @return 值
     */
    public int load2Byte(int address) {
        if (address > (M6502.DEFAULT_INTERNAL_RAM_SIZE - 1)) {
            throw new MemoryIndexOutOfBoundsException("CPU 最大支持寻址范围为0 - 0xffff!");
        }
        if (address < 0x1fff) {
            return this.memory.read(address & 0x7ff) | (this.memory.read((address + 1) & 0x7ff) << 8);
        } else {
            //TODO Mapper Read
            return 0;
        }
    }

    /**
     * 写入内存 1字节(8Bit)
     *
     * @param address 地址
     * @return 值
     */
    public abstract int write(int address, int data);

    /**
     * 写入2字节（16Bit）
     *
     * @param address 地址
     * @return 值
     */
    public abstract int write2Byte(int address, int data);

    /**
     * 累加寄存器
     *
     * @return
     */
    public Register<Integer, Integer> getAR() {
        Register<Integer, Integer> register = findRegisterByName("AR");
        return register;
    }

    /**
     * 程序寄存器
     *
     * @return
     */
    public Register<Integer, Integer> getPC() {
        Register<Integer, Integer> register = findRegisterByName("PC");
        return register;
    }

    /**
     * 栈寄存器
     *
     * @return
     */
    public Register<Integer, Integer> getSP() {
        Register<Integer, Integer> register = findRegisterByName("SP");
        return register;
    }

    /**
     * 状态寄存器
     *
     * @return
     */
    public StatusRegister<Integer, Integer> getSR() {
        StatusRegister<Integer, Integer> register = (StatusRegister<Integer, Integer>) findRegisterByName("SR");
        return register;
    }

    /**
     * X 寄存器
     *
     * @return
     */
    public Register<Integer, Integer> getXR() {
        Register<Integer, Integer> register = findRegisterByName("YR");
        return register;
    }

    /**
     * Y 寄存器
     *
     * @return
     */
    public Register<Integer, Integer> getYR() {
        Register<Integer, Integer> register = findRegisterByName("XR");
        return register;
    }

    /**
     * 根据名称查找寄存器
     *
     * @param name 名称
     * @return
     */
    protected Register findRegisterByName(String name) {
        List<Register> registers = this.getRegisters();
        if (registers != null) {

            for (Register register : registers) {
                if (name.equals(register.getName())) {
                    return register;
                }
            }

        }
        return null;
    }

    public Integer getCurrentPC() {
        return currentPC;
    }

    public void setCurrentPC(Integer currentPC) {
        this.currentPC = currentPC;
    }

    public Integer getCurrentPCValue() {
        return this.getMemory().read(getCurrentPC());
    }

    @Override
    public Map<String, AddressMode> getAddressModeMap() {
        return addressModeMap;
    }

    @Override
    public void setAddressModeMap(Map<String, AddressMode> addressModeMap) {
        this.addressModeMap = addressModeMap;
    }

    @Override
    public List<Register> getRegisters() {
        return registers;
    }

    @Override
    public void setRegisters(List<Register> registers) {
        this.registers = registers;
    }

    @Override
    public String getDeviceName() {
        return deviceName;
    }

    @Override
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    @Override
    public String getDeviceCode() {
        return deviceCode;
    }

    @Override
    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    @Override
    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public List<DeviceInfo> getDeviceContents() {
        return deviceContents;
    }

    @Override
    public void setDeviceContents(List<DeviceInfo> deviceContents) {
        this.deviceContents = deviceContents;
    }
}
