package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * ORA指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class ORA extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public ORA(M6502 cpu) {
        super(cpu);
        this.setAliasName("ORA");
        this.setCode("ORA");
        this.addMachineCodeByArray(new String[]{
                "09", "05", "15", "0D",
                "1D", "19", "01", "11"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("09", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("05", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("15", 2, 4),
                M6502InstructionInfoBuilder.absolute("0D", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("1D", 3, 4, true, false),
                M6502InstructionInfoBuilder.absoluteY("19", 3, 4, true, false),
                M6502InstructionInfoBuilder.indirectXB("01", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("11", 2, 5, true, false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        int temp = src | ac;
        cpu.getSR().initStatus(SR.NEGATIVE, src < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (src & 0xff) == 0); //计算结果出现0结果设置
        cpu.getAR().setValue(temp);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
