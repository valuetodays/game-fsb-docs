package com.omuao.rom.nes.cpu.register.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.register.Register;

/**
 * X 寄存器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class XR implements Register<Integer, Integer> {
    /**
     * XR 寄存器 名称
     */
    private String name;

    /**
     * 寄存器值
     */
    private Integer value;

    public XR() {
        this.name = "XR";
        this.value = 0;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public void setValue(Integer value) {
        this.value = value;
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
