package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 累加器寻址 1byte
 * <p>
 * 指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class AccumulatorAddressModeImpl extends M6502AddressMode {

    public AccumulatorAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int address = cpu.getAR().getValue();
        return address;
    }

}
