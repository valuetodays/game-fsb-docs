package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * STX指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class STX extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public STX(M6502 cpu) {
        super(cpu);
        this.setAliasName("STX");
        this.setCode("STX");
        this.addMachineCodeByArray(new String[]{
                "86","96","8E"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.zeroPage("86", 2, 3),
                M6502InstructionInfoBuilder.zeroPageY("96",2,4),
                M6502InstructionInfoBuilder.absolute("8E",3,4),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        cpu.write(Integer.parseInt(machineCode(), 16), this.addressModeValue());
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
