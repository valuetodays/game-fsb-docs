package com.omuao.rom.nes.cpu.memory.impl;

import com.omuao.rom.nes.common.exception.MemoryIOException;
import com.omuao.rom.nes.common.exception.MemoryIndexOutOfBoundsException;
import com.omuao.rom.nes.common.model.device.DeviceInfo;
import com.omuao.rom.nes.common.model.device.DeviceType;
import com.omuao.rom.nes.common.model.memory.Memory;

import java.util.ArrayList;
import java.util.List;

/**
 * CPU内存实现类
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class CPUMemoryImpl implements Memory {

    /**
     * 数据
     */
    private int[] data;

    /**
     * 数据总线位数
     */
    private int dataBusBit;

    /**
     * 数据总线数据
     */
    private transient int intDataBus;

    /**
     * 只读
     */
    private boolean read;

    /**
     * 只写
     */
    private boolean write;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备编码
     */
    private String deviceCode;

    /**
     * 设备类型
     */
    private DeviceType deviceType;

    /**
     * 设备信息
     */
    private List<DeviceInfo> deviceContents;

    public CPUMemoryImpl(int[] data) {
        this.data = data;
        initMemoryInfo();
    }

    private void initMemoryInfo() {
        this.deviceName = "Memory"; //设备名称
        this.deviceCode = "Memory"; //设备编码
        this.deviceType = DeviceType.MEMORY; //设备类型
        this.deviceContents = new ArrayList<>();//设备信息
    }

    @Override
    public int read(int address) {
        if (!read) {
            throw new MemoryIOException("内存为写内存！");
        }

        if (address > data.length) {
            throw new MemoryIndexOutOfBoundsException("内存数组越界！");
        }
        return this.data[address];
    }

    @Override
    public void write(int address, int data) {
        if (!write) {
            throw new MemoryIOException("内存为只读内存！");
        }
        if (address > this.data.length) {
            throw new MemoryIndexOutOfBoundsException("内存数组越界！");
        }
        this.data[address] = data;
    }

    @Override
    public boolean readOnly() {
        return (!write) && read;
    }

    @Override
    public boolean writeOnly() {
        return write && (!read);
    }

    @Override
    public void setDataBusBit(int dataBusBit) {
        this.dataBusBit = dataBusBit;
    }

    @Override
    public int getDataBusBit() {
        return this.dataBusBit;
    }

    @Override
    public int getIntDataBus() {
        return this.intDataBus;
    }

    @Override
    public void setWritable(boolean writable) {
        this.write = writable;
    }

    @Override
    public void setReadable(boolean readable) {
        this.read = readable;
    }

    @Override
    public String getDeviceName() {
        return deviceName;
    }

    @Override
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    @Override
    public String getDeviceCode() {
        return deviceCode;
    }

    @Override
    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    @Override
    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public List<DeviceInfo> getDeviceContents() {
        return deviceContents;
    }

    @Override
    public void setDeviceContents(List<DeviceInfo> deviceContents) {
        this.deviceContents = deviceContents;
    }
}
