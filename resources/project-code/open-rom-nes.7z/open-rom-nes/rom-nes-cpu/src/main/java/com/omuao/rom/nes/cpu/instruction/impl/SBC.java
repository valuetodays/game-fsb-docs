package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * SBC指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class SBC extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public SBC(M6502 cpu) {
        super(cpu);
        this.setAliasName("SBC");
        this.setCode("SBC");
        this.addMachineCodeByArray(new String[]{
                "E9", "E5", "F5", "ED",
                "FD", "F9", "E1", "F1"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("E9", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("E5", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("F5", 2, 4),
                M6502InstructionInfoBuilder.absolute("ED", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("FD", 3, 4, true, false),
                M6502InstructionInfoBuilder.absoluteY("F9", 3, 4, true, false),
                M6502InstructionInfoBuilder.indirectXB("E1", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("F1", 2, 5, true, false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        boolean isCarry = cpu.getSR().getStatus(SR.CARRY);//根据进位标记判断CPU是否有进位操作
        boolean isDecimal = cpu.getSR().getStatus(SR.DECIMAL_MODE);//判断CPU是否是进行十进制模式运算
        long temp = (ac - src - (isCarry ? 0 : 1)) & 0x0FFFFFFFF;

        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果出现0结果设置
        cpu.getSR().initStatus(SR.OVERFLOW, !(((ac ^ src) & 0x80) >= 0) && (((ac ^ temp) & 0x80) >= 0));//计算结果溢出设置
        if (isDecimal) {
            if (((ac & 0xf) - (isCarry ? 0 : 1)) < (src & 0xf)) {
                temp -= 6;
            }
            if (temp > 0x99) {
                temp -= 0x60;
            }
        }
        cpu.getSR().initStatus(SR.CARRY, temp < 0x100); //计算结果进位时设置
        cpu.getAR().setValue((int) (temp & 0xff));
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
