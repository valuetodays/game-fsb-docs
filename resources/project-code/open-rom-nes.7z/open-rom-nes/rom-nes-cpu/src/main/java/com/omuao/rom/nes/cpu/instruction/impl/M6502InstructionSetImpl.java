package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.instruction.Instruction;
import com.omuao.rom.nes.common.model.instruction.InstructionSet;
import com.omuao.rom.nes.common.model.instruction.impl.AbstractInstructionSet;
import com.omuao.rom.nes.cpu.M6502;

import java.util.ArrayList;
import java.util.List;

/**
 * 6502 指令集
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class M6502InstructionSetImpl extends AbstractInstructionSet implements InstructionSet {

    /**
     * 指令集
     */
    private List<Instruction> instructions;

    /**
     * CPU
     */
    private M6502 cpu;

    public M6502InstructionSetImpl(M6502 cpu) {
        this.cpu = cpu;
        instructions = new ArrayList<>();
        instructions.add(new ADC(cpu));
        instructions.add(new ASL(cpu));
        instructions.add(new BCC(cpu));
        instructions.add(new BCS(cpu));
        instructions.add(new BEQ(cpu));
        instructions.add(new BIT(cpu));
        instructions.add(new BMI(cpu));
        instructions.add(new BNE(cpu));
        instructions.add(new BPL(cpu));
        instructions.add(new BRK(cpu));
        instructions.add(new BVC(cpu));
        instructions.add(new BVS(cpu));
        instructions.add(new CLC(cpu));
        instructions.add(new CLD(cpu));
        instructions.add(new CLI(cpu));
        instructions.add(new CLV(cpu));
        instructions.add(new CMP(cpu));
        instructions.add(new CPX(cpu));
        instructions.add(new CPY(cpu));
        instructions.add(new DEC(cpu));
        instructions.add(new DEX(cpu));
        instructions.add(new DEY(cpu));
        instructions.add(new EOR(cpu));
        instructions.add(new INC(cpu));
        instructions.add(new INX(cpu));
        instructions.add(new INY(cpu));
        instructions.add(new JMP(cpu));
        instructions.add(new JSR(cpu));
        instructions.add(new LDA(cpu));
        instructions.add(new LDX(cpu));
        instructions.add(new LDY(cpu));
        instructions.add(new LSR(cpu));
        instructions.add(new NOP(cpu));
        instructions.add(new ORA(cpu));
        instructions.add(new PHA(cpu));
        instructions.add(new PHP(cpu));
        instructions.add(new PLA(cpu));
        instructions.add(new PLP(cpu));
        instructions.add(new ROL(cpu));
        instructions.add(new ROR(cpu));
        instructions.add(new RTI(cpu));
        instructions.add(new RTS(cpu));
        instructions.add(new SBC(cpu));
        instructions.add(new SEC(cpu));
        instructions.add(new SED(cpu));
        instructions.add(new SEI(cpu));
        instructions.add(new STA(cpu));
        instructions.add(new STX(cpu));
        instructions.add(new STY(cpu));
        instructions.add(new TAX(cpu));
        instructions.add(new TAY(cpu));
        instructions.add(new TSX(cpu));
        instructions.add(new TXA(cpu));
        instructions.add(new TXS(cpu));
        instructions.add(new TYA(cpu));
    }

    @Override
    public List<Instruction> getInstructions() {
        return instructions;
    }

    @Override
    public void setInstructions(List<Instruction> instructions) {
        this.instructions = instructions;
    }

    @Override
    public Instruction getInstructionByCode() {
        return null;
    }

}
