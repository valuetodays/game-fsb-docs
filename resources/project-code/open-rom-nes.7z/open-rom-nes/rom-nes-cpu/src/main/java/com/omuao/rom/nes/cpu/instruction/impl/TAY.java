package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * TAY指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class TAY extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public TAY(M6502 cpu) {
        super(cpu);
        this.setAliasName("TAY");
        this.setCode("TAY");
        this.addMachineCodeByArray(new String[]{
                "A8"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("A8", 1, 2),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = cpu.getAR().getValue() & 0xff;
        cpu.getSR().initStatus(SR.NEGATIVE, src < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (src & 0xff) == 0); //计算结果出现0结果设置
        cpu.getYR().setValue(src);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
