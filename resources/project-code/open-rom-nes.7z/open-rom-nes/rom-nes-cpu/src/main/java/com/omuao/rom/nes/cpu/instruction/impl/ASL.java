package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.address.impl.M6502AddressMode;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * ASL指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class ASL extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public ASL(M6502 cpu) {
        super(cpu);
        this.setAliasName("ASL");
        this.setCode("ASL");
        this.addMachineCodeByArray(new String[]{
                "0A", "06", "16", "0E",
                "1E"
        });

        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.accumulator("0A", 1, 2),
                M6502InstructionInfoBuilder.zeroPage("06", 2, 5),
                M6502InstructionInfoBuilder.zeroPageX("16", 2, 6),
                M6502InstructionInfoBuilder.absolute("0E", 3, 6),
                M6502InstructionInfoBuilder.absoluteX("1E", 3, 7)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = addressModeValue();
        cpu.getSR().initStatus(SR.CARRY, (src & 0x80) > 0); //计算结果出现进位设置
        int temp = src << 1;
        temp = temp & 0xff;
        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, temp == 0); //计算结果出现0结果设置

        if (M6502AddressMode.ACCUMULATOR.equals(addressMode())) {
            //存于累加器
            cpu.getAR().setValue(temp);
        } else {
            //存于内存中
            cpu.getMemory().write(Integer.parseInt(machineCode(), 16), temp);
        }

    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
