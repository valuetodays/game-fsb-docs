package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * LDA指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class LDA extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public LDA(M6502 cpu) {
        super(cpu);
        this.setAliasName("LDA");
        this.setCode("LDA");
        this.addMachineCodeByArray(new String[]{
                "A9", "A5", "B5", "AD",
                "BD", "B9", "A1", "B1"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("A9", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("A5", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("B5", 2, 4),
                M6502InstructionInfoBuilder.absolute("AD", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("BD", 3, 4, true, false),
                M6502InstructionInfoBuilder.absoluteY("B9", 3, 4, true, false),
                M6502InstructionInfoBuilder.indirectXB("A1", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("B1", 2, 5, true, false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();
        cpu.getSR().initStatus(SR.NEGATIVE, src < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (src & 0xff) == 0); //计算结果出现0结果设置
        cpu.getAR().setValue(src);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
