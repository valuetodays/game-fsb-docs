package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * CPY指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class CPY extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public CPY(M6502 cpu) {
        super(cpu);
        this.setAliasName("CPY");
        this.setCode("CPY");
        this.addMachineCodeByArray(new String[]{
                "C0","C4","CC"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("C0", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("C4", 2, 3),
                M6502InstructionInfoBuilder.absolute("CC", 3, 4)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int yr = cpu.getYR().getValue();//算数寄存器的值
        int temp = yr - src;//计算结果
        cpu.getSR().initStatus(SR.CARRY, temp > 0xff); //计算结果进位时设置
        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果出现0结果设置
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
