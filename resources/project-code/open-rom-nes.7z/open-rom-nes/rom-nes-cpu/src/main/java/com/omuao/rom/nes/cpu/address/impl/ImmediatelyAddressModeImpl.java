package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 立即寻址 2Byte
 * <p>
 * 采用立即寻址的指令都是2字节
 * <p>
 * 指令机器码  直接操作数
 * 例如 ：LDA #$FF  #号表示立即数$表示十六进制数
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class ImmediatelyAddressModeImpl extends M6502AddressMode {

    public ImmediatelyAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int address = cpu.getPC().getValue() + 1;
        //立即寻址，即PC +1 即是地址内容，后面是立即数，立即寻址为2字节
        return address;
    }

}
