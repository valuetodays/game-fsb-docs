package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * STA指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class STA extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public STA(M6502 cpu) {
        super(cpu);
        this.setAliasName("STA");
        this.setCode("STA");
        this.addMachineCodeByArray(new String[]{
                "85", "95", "8D", "9D",
                "99", "81", "91"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.zeroPage("85", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("95", 2, 4),
                M6502InstructionInfoBuilder.absolute("8D", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("9D", 3, 5),
                M6502InstructionInfoBuilder.absoluteY("99", 3, 5),
                M6502InstructionInfoBuilder.indirectXB("81", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("91", 2, 6),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        cpu.write(Integer.parseInt(machineCode(), 16), this.addressModeValue());
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
