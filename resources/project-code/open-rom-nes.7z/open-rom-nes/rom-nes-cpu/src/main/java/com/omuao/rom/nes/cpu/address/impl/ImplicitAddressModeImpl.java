package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 隐含寻址 1Byte
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class ImplicitAddressModeImpl extends M6502AddressMode {

    public ImplicitAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        return cpu.getPC().getValue();
    }

}
