package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * SED指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class SED extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public SED(M6502 cpu) {
        super(cpu);
        this.setAliasName("SED");
        this.setCode("SED");
        this.addMachineCodeByArray(new String[]{
                "F8"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("F8", 1, 2),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        cpu.getSR().initStatus(SR.DECIMAL_MODE, true);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
