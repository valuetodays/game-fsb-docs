package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 先间接寻址，然后Y索引寻址 3Byte
 * <p>
 * 指令码  地址低位  地址高位
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class IndirectYIndexAfterAddressModeImpl extends M6502AddressMode {

    public IndirectYIndexAfterAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int pc = cpu.getPC().getValue();
        int yr = cpu.getYR().getValue();
        int address = cpu.load2Byte(cpu.load(pc + 2));
        /*if ((address & 0xff00) != ((address + yr) & 0xff00)) {
            clockAdd = 1;//寻址周期
        }*/
        address += yr;
        return address;
    }

}

