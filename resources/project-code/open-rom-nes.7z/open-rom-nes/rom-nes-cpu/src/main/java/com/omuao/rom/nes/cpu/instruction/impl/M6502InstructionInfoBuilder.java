package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.common.model.instruction.impl.InstructionInfoImpl;
import com.omuao.rom.nes.cpu.address.impl.M6502AddressMode;

/**
 * 指令信息构造器
 *
 * @author yumi@oumao.com
 * @since 2019-09-25
 **/
public class M6502InstructionInfoBuilder {

    public static InstructionInfo absolute(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo absoluteX(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE_X, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo absoluteY(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE_Y, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo accumulator(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ACCUMULATOR, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo immediately(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.IMMEDIATELY, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo implicit(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.IMPLICIT, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo indirect(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo indirectXB(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT_XB, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo indirectYA(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT_YA, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo relative(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.RELATIVE, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo zeroPage(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo zeroPageX(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE_X, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo zeroPageY(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE_Y, needCheckCrossPage, needCheckBranch);
    }

    public static InstructionInfo absolute(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE, false, false);
    }

    public static InstructionInfo absoluteX(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE_X, false, false);
    }

    public static InstructionInfo absoluteY(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ABSOLUTE_Y, false, false);
    }

    public static InstructionInfo accumulator(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ACCUMULATOR, false, false);
    }

    public static InstructionInfo immediately(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.IMMEDIATELY, false, false);
    }

    public static InstructionInfo implicit(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.IMPLICIT, false, false);
    }

    public static InstructionInfo indirect(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT, false, false);
    }

    public static InstructionInfo indirectXB(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT_XB, false, false);
    }

    public static InstructionInfo indirectYA(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.INDIRECT_YA, false, false);
    }

    public static InstructionInfo relative(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.RELATIVE, false, false);
    }

    public static InstructionInfo zeroPage(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE, false, false);
    }

    public static InstructionInfo zeroPageX(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE_X, false, false);
    }

    public static InstructionInfo zeroPageY(String machineCode, Integer length, Integer clock) {
        return new InstructionInfoImpl(machineCode, length, clock, M6502AddressMode.ZERO_PAGE_Y, false, false);
    }
}
