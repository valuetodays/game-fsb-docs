package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * BMI指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class BMI extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public BMI(M6502 cpu) {
        super(cpu);
        this.setAliasName("BMI");
        this.setCode("BMI");
        this.addMachineCodeByArray(new String[]{
                "30"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.relative("30", 2, 2,false,true),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int clock = this.getClock();//指令需要执行需要的周期数
        int pc = cpu.getPC().getValue(); //程序计数器
        int src = this.addressModeValue();//寻址后的值
        boolean isNegative = cpu.getSR().getStatus(SR.NEGATIVE);//根据负数标记判断计算是否存在负数
        if (isNegative) {
            //如果再同页上，需要一个周期，如果不同页上需要两个周期
            clock = clock + ((pc & 0xff00) != (relative(pc, src) & 0xff00) ? 2 : 1);
            //设置当前程序计数器的值
            cpu.getPC().setValue(relative(pc, src));
        }
        this.setClock(clock);
    }

    private int relative(int pc, int src) {
        pc += src;
        return pc;
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
