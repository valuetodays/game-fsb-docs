package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.common.model.address.AbstractAddressMode;
import com.omuao.rom.nes.common.model.address.AddressMode;
import com.omuao.rom.nes.cpu.M6502;

/**
 * 6502 寻址方式
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public abstract class M6502AddressMode extends AbstractAddressMode<Integer, Integer> implements AddressMode<Integer, Integer> {

    /**
     * 绝对寻址
     */
    public static final String ABSOLUTE = "ABSOLUTE";

    /**
     * 绝对寻址 X寄存器变址
     */
    public static final String ABSOLUTE_X = "ABSOLUTE_X";

    /**
     * 绝对寻址 Y寄存器变址
     */
    public static final String ABSOLUTE_Y = "ABSOLUTE_Y";

    /**
     * 累加器寻址
     */
    public static final String ACCUMULATOR = "ACCUMULATOR";

    /**
     * 立即寻址
     */
    public static final String IMMEDIATELY = "IMMEDIATELY";

    /**
     * 隐含寻址
     */
    public static final String IMPLICIT = "IMPLICIT";

    /**
     * 间接寻址
     */
    public static final String INDIRECT = "INDIRECT";

    /**
     * 先寄存器 X 寻址，再间接寻址
     */
    public static final String INDIRECT_XB = "INDIRECT_XB";

    /**
     * 先间接寻址，再Y寄存器寻址
     */
    public static final String INDIRECT_YA = "INDIRECT_YA";

    /**
     * 相对寻址
     */
    public static final String RELATIVE = "RELATIVE";

    /**
     * 零页寻址
     */
    public static final String ZERO_PAGE = "ZERO_PAGE";

    /**
     * 零页寻址，X寄存器变址
     */
    public static final String ZERO_PAGE_X = "ZERO_PAGE_X";

    /**
     * 零页寻址，Y寄存器变址
     */
    public static final String ZERO_PAGE_Y = "ZERO_PAGE_Y";


    /**
     * 6502 CPU
     */
    protected M6502 cpu;


    public M6502AddressMode(M6502 cpu) {
        this.cpu = cpu;
    }
}
