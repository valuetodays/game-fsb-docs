package com.omuao.rom.nes.cpu.address.impl;

import com.omuao.rom.nes.cpu.M6502;

/**
 * 零页寻址 Y寄存器索引变址 2Byte
 * <p>
 * 指令码  地址
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public final class ZeroPageYIndexAddressModeImpl extends M6502AddressMode {

    public ZeroPageYIndexAddressModeImpl(M6502 cpu) {
        super(cpu);
    }

    @Override
    public Integer addressing(Integer integer) {
        int pc = cpu.getPC().getValue();
        int yr = cpu.getYR().getValue();
        int address = (cpu.load(pc + 1) + yr) & 0xff;
        return address;
    }

}
