package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.address.AddressMode;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.common.model.instruction.impl.InstructionImpl;
import com.omuao.rom.nes.cpu.M6502;

/**
 * 抽象指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public abstract class AbstractM6502Instruction extends InstructionImpl implements AlgorithmInstruction<Integer> {

    /**
     * 6502 CPU
     */
    protected M6502 cpu;

    public AbstractM6502Instruction(M6502 cpu) {
        this.cpu = cpu;
    }

    @Override
    public void calculate() {
        int pc = cpu.getPC().getValue(); //当前指令地址
        cpu.setCurrentPC(pc);
        InstructionInfo instructionInfo = this.getInstructionInfo();//指令信息
        this.setClock(instructionInfo.getClock()); //设置当前指令的时钟周期
        this.execute(); //执行指令
        int temp = pc + instructionInfo.getLength(); //计算执行指令后指向下一条指令地址
        cpu.getPC().setValue(temp);//设置下一条指令的内存地址
    }

    public abstract void execute();

    @Override
    public String machineCode() {
        if (cpu != null) {

            Integer data = cpu.getCurrentPCValue();

            String hex = Integer.toHexString(data);

            if (hex.length() <= 1) {
                hex = "0" + hex;
            }

            return hex;

        }
        return super.machineCode();
    }

    /**
     * 寻址后的值
     *
     * @return
     */
    protected Integer addressModeValue() {

        AddressMode addressMode = cpu.getAddressModeMap().get(addressMode());

        Integer addressing = (Integer) addressMode.addressing(Integer.parseInt(machineCode(), 16));

        int value = cpu.load(addressing);

        return value;
    }

}
