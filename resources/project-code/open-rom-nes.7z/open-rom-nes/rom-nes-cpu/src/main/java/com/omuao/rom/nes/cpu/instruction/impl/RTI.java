package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * RTI指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class RTI extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public RTI(M6502 cpu) {
        super(cpu);
        this.setAliasName("RTI");
        this.setCode("RTI");
        this.addMachineCodeByArray(new String[]{
                "40"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("40", 1, 6),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = cpu.pull();
        cpu.getSR().setValue(src);
        src = cpu.pull();
        src |= (cpu.pull() << 8);
        cpu.getPC().setValue(src);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
