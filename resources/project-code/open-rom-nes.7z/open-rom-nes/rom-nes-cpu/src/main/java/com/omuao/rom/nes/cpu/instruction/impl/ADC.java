package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * ADC指令
 * <p>
 * 对寻址数据和 累加器中的数据进行求和运算，存于累加器寄存器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class ADC extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public ADC(M6502 cpu) {
        super(cpu);
        this.setAliasName("ADC");
        this.setCode("ADC");
        this.addMachineCodeByArray(new String[]{
                "69", "65", "75", "6D",
                "7D", "79", "61", "71"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("69", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("65", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("75", 2, 4),
                M6502InstructionInfoBuilder.absolute("6D", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("7D", 3, 4, true, false),
                M6502InstructionInfoBuilder.absoluteY("79", 3, 4, true, false),
                M6502InstructionInfoBuilder.indirectXB("61", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("71", 2, 5, true, false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }


    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        boolean isCarry = cpu.getSR().getStatus(SR.CARRY);//根据进位标记判断CPU是否有进位操作
        boolean isDecimal = cpu.getSR().getStatus(SR.DECIMAL_MODE);//判断CPU是否是进行十进制模式运算
        int temp = src + ac + (isCarry ? 1 : 0); //计算结果，进位则+1
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果为0时设置

        if (isDecimal) {
            if (((ac & 0xf) + (src & 0xf) + (isCarry ? 1 : 0)) > 9) {
                temp += 6;
            }
            cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
            cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果出现0结果设置
            cpu.getSR().initStatus(SR.OVERFLOW, !(((ac ^ src) & 0x80) >= 0) && (((ac ^ temp) & 0x80) >= 0));//计算结果溢出设置
            if (temp > 0x99) {
                temp += 96;
            }
            cpu.getSR().initStatus(SR.CARRY, temp > 0x99);

        } else {
            cpu.getSR().initStatus(SR.NEGATIVE, temp < 0);//计算结果出现负数设置
            cpu.getSR().initStatus(SR.OVERFLOW, !(((ac ^ src) & 0x80) >= 0) && (((ac ^ temp) & 0x80) >= 0));//计算结果溢出设置
            cpu.getSR().initStatus(SR.CARRY, temp > 0xff); //计算结果进位时设置
        }
        cpu.getAR().setValue(temp & 0xff);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
