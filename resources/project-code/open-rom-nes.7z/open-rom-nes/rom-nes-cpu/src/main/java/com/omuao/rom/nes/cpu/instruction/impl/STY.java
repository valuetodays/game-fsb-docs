package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;

/**
 * STY指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class STY extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public STY(M6502 cpu) {
        super(cpu);
        this.setAliasName("STY");
        this.setCode("STY");
        this.addMachineCodeByArray(new String[]{
                "84","94","8C"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.zeroPage("84", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("94",2,4),
                M6502InstructionInfoBuilder.absolute("8C",3,4),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        cpu.write(Integer.parseInt(machineCode(), 16), this.addressModeValue());
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
