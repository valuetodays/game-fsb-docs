package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * DEC指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class DEC extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public DEC(M6502 cpu) {
        super(cpu);
        this.setAliasName("DEC");
        this.setCode("DEC");
        this.addMachineCodeByArray(new String[]{
                "C6", "D6", "CE", "DE"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.zeroPage("C6", 2, 5),
                M6502InstructionInfoBuilder.zeroPageX("D6", 2, 6),
                M6502InstructionInfoBuilder.absolute("CE", 3, 6),
                M6502InstructionInfoBuilder.absoluteX("DE", 3, 7)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int temp = (src - 1) & 0xff;//计算结果
        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果出现0结果设置
        cpu.write(Integer.parseInt(machineCode(), 16), temp);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
