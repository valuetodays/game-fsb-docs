package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * EOR指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class EOR extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public EOR(M6502 cpu) {
        super(cpu);
        this.setAliasName("EOR");
        this.setCode("EOR");
        this.addMachineCodeByArray(new String[]{
                "49", "45", "55", "4D",
                "5D", "59", "41", "51"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("49", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("45", 2, 3),
                M6502InstructionInfoBuilder.zeroPageX("55", 2, 4),
                M6502InstructionInfoBuilder.absolute("4D", 3, 4),
                M6502InstructionInfoBuilder.absoluteX("5D", 3, 4, true, false),
                M6502InstructionInfoBuilder.absoluteY("59", 3, 4, true, false),
                M6502InstructionInfoBuilder.indirectXB("41", 2, 6),
                M6502InstructionInfoBuilder.indirectYA("51", 2, 5, true, false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        int temp = src ^ ac;
        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0); //计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果出现0结果设置
        cpu.getAR().setValue(temp);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
