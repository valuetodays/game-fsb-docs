package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * BEQ指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class BEQ extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public BEQ(M6502 cpu) {
        super(cpu);
        this.setAliasName("BEQ");
        this.setCode("BEQ");
        this.addMachineCodeByArray(new String[]{
                "F0"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.relative("F0", 2, 2, false, true),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int clock = this.getClock();//指令需要执行需要的周期数
        int pc = cpu.getPC().getValue(); //程序计数器
        int src = this.addressModeValue();//寻址后的值
        boolean isZero = cpu.getSR().getStatus(SR.ZERO);//根据零标记判断CPU是否有进位操作
        if (isZero) {
            //如果再同页上，需要一个周期，如果不同页上需要两个周期
            clock = clock + ((pc & 0xff00) != (relative(pc, src) & 0xff00) ? 2 : 1);
            //设置当前程序计数器的值
            cpu.getPC().setValue(relative(pc, src));
        }
        this.setClock(clock);
    }

    private int relative(int pc, int src) {
        pc += src;
        return pc;
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
