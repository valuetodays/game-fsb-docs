package com.omuao.rom.nes.cpu.register.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.register.Register;
import com.omuao.rom.nes.common.model.register.StatusRegister;

import java.util.HashMap;
import java.util.Map;

/**
 * 状态寄存器
 * 7 6 5 4 3 2 1 0 Bit No.（位编号）
 * N V - B D I Z C
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class SR implements Register<Integer, Integer>, StatusRegister<Integer, Integer> {

    /**
     * 进位标记
     */
    public static final String CARRY = "C";

    /**
     * 零标记
     */
    public static final String ZERO = "Z";

    /**
     * 硬件中断标记
     */
    public static final String INTERRUPT_DISABLE = "I";

    /**
     * 十进制模式标记
     */
    public static final String DECIMAL_MODE = "D";

    /**
     * 程序中断标记
     */
    public static final String BREAK_COMMAND = "B";

    /**
     * 未使用的标记
     */
    public static final String NOT_USED = "-";

    /**
     * 溢出标记
     */
    public static final String OVERFLOW = "V";

    /**
     * 负数标记
     */
    public static final String NEGATIVE = "N";

    /**
     * SR 寄存器 名称
     */
    private String name;

    /**
     * 寄存器值
     */
    private Integer value;

    /**
     * 状态Map
     */
    private Map<String, Boolean> statusMap;

    public SR() {
        this.name = "SR";
        this.value = 0;
        this.statusMap = new HashMap<>();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public void setValue(Integer value) {
        this.value = value;
        Map<String, Boolean> map = valueToMap(value);
        statusMap = map;
    }

    private Map<String, Boolean> valueToMap(Integer value) {
        Map<String, Boolean> map = new HashMap();
        boolean carryFlag = ((value) & 1) == 1;
        boolean zeroFlag = ((value >> 1) & 1) == 1;
        boolean interruptDisableFlag = ((value >> 2) & 1) == 1;
        boolean decimalModeFlag = ((value >> 3) & 1) == 1;
        boolean breakCommandFlag = ((value >> 4) & 1) == 1;
        boolean notUsedFlag = ((value >> 5) & 1) == 1;
        boolean overflowFlag = ((value >> 6) & 1) == 1;
        boolean negativeFlag = ((value >> 7) & 1) == 1;
        //N V - B D I Z C
        map.put("C", carryFlag);
        map.put("Z", zeroFlag);
        map.put("I", interruptDisableFlag);
        map.put("D", decimalModeFlag);
        map.put("B", breakCommandFlag);
        map.put("-", notUsedFlag);
        map.put("V", overflowFlag);
        map.put("N", negativeFlag);
        return map;
    }

    private int mapToInt(Map<String, Boolean> map) {
        int carryFlag = map.getOrDefault("C", false) ? 1 : 0;
        int zeroFlag = map.getOrDefault("Z", false) ? 1 : 0;
        int interruptDisableFlag = map.getOrDefault("I", false) ? 1 : 0;
        int decimalModeFlag = map.getOrDefault("D", false) ? 1 : 0;
        int breakCommandFlag = map.getOrDefault("B", false) ? 1 : 0;
        int notUsedFlag = map.getOrDefault("-", false) ? 1 : 0;
        int overflowFlag = map.getOrDefault("V", false) ? 1 : 0;
        int negativeFlag = map.getOrDefault("N", false) ? 1 : 0;
        return (carryFlag)
                | (zeroFlag << 1)
                | (interruptDisableFlag << 2)
                | (decimalModeFlag << 3)
                | (breakCommandFlag << 4)
                | (notUsedFlag << 5)
                | (overflowFlag << 6)
                | (negativeFlag << 7);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }

    @Override
    public Map<String, Boolean> getStatusMap() {
        return this.statusMap;
    }

    @Override
    public Boolean getStatus(String key) {
        return this.statusMap.getOrDefault(key, false);
    }

    @Override
    public void initStatus(String key) {
        this.statusMap.put(key, false);
        this.value = mapToInt(this.statusMap);
    }

    @Override
    public void initStatus(String key, Boolean value) {
        this.statusMap.put(key, value);
        this.value = mapToInt(this.statusMap);
    }
}
