package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * CLD指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class CLD extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public CLD(M6502 cpu) {
        super(cpu);
        this.setAliasName("CLD");
        this.setCode("CLD");
        this.addMachineCodeByArray(new String[]{
                "D8"
        });
        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.implicit("D8", 1, 2),
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        cpu.getSR().initStatus(SR.DECIMAL_MODE, false);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
