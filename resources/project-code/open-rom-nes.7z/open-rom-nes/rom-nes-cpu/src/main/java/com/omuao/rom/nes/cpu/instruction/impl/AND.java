package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.converter.Converter;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;
import com.omuao.rom.nes.cpu.M6502;
import com.omuao.rom.nes.cpu.register.impl.SR;

/**
 * AND 指令
 * 对寻址数据和 累加器中的数据进行位与运算，存于累加器寄存器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public final class AND extends AbstractM6502Instruction implements AlgorithmInstruction<Integer> {

    public AND(M6502 cpu) {
        super(cpu);
        this.setAliasName("AND");
        this.setCode("AND");
        this.addMachineCodeByArray(new String[]{
                "29","25","35","2D",
                "3D","39","21","31"
        });

        this.addInstructionInfoByArray(new InstructionInfo[]{
                M6502InstructionInfoBuilder.immediately("29", 2, 2),
                M6502InstructionInfoBuilder.zeroPage("25",2,3),
                M6502InstructionInfoBuilder.zeroPageX("35",2,4),
                M6502InstructionInfoBuilder.absolute("2D",3,4),
                M6502InstructionInfoBuilder.absoluteY("3D",3,4,true,false),
                M6502InstructionInfoBuilder.absoluteY("39",3,4,true,false),
                M6502InstructionInfoBuilder.indirectXB("21",2,6),
                M6502InstructionInfoBuilder.indirectYA("31",2,5,true,false)
        });
    }

    @Override
    public Integer getOperationalData() {
        return null;
    }

    @Override
    public void execute() {
        int src = this.addressModeValue();//寻址方式的值
        int ac = cpu.getAR().getValue();//算数寄存器的值
        int temp = src & ac;//进行位与计算
        cpu.getSR().initStatus(SR.NEGATIVE, temp < 0);//计算结果出现负数设置
        cpu.getSR().initStatus(SR.ZERO, (temp & 0xff) == 0); //计算结果为0时设置
        cpu.getAR().setValue(temp & 0xff);
    }

    @Override
    public Converter getConverter() {
        return null;
    }

    @Override
    public void setConverter(Converter converter) {

    }
}
