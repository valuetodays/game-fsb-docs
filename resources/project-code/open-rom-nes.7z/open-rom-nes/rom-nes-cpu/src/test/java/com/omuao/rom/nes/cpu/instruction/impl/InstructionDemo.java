package com.omuao.rom.nes.cpu.instruction.impl;

import com.omuao.rom.nes.common.model.device.Device;
import com.omuao.rom.nes.common.model.instruction.AlgorithmInstruction;
import com.omuao.rom.nes.cpu.M6502;
import org.junit.Before;
import org.junit.Test;

import java.util.Map;

import static org.junit.Assert.assertEquals;

/**
 * 指令集测试
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class InstructionDemo {

    private static M6502 cpu;

    /**
     * 初始化
     */
    @Before
    public void init() {
        cpu = new M6502() {
            @Override
            public void push(int i) {

            }

            @Override
            public int pull() {
                return 0;
            }

            @Override
            public int write(int address, int data) {
                return 0;
            }

            @Override
            public int write2Byte(int address, int data) {
                return 0;
            }

            @Override
            public int emulate() {
                return 0;
            }

            @Override
            public Map<String, Device> getDeviceMap() {
                return null;
            }

            @Override
            public void setDeviceMap(Map<String, Device> deviceMap) {

            }
        };
        cpu.getMemory().write(0x00, 0x69);
        cpu.getMemory().write(0x01,0x01);
        cpu.getAR().setValue(-1);
    }

    /**
     * ADC 测试指令
     */
    @Test
    public void testADC() {
        AlgorithmInstruction instruction = new ADC(cpu);
        instruction.calculate();
        println(instruction);
        System.out.println(cpu.getAR().getValue());
        System.out.println(cpu.getSR().getStatus("N"));
    }

    /**
     * AND 测试指令
     */
    @Test
    public void testAND() {
        AlgorithmInstruction instruction = new AND(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * ASL 测试指令
     */
    @Test
    public void testASL() {
        AlgorithmInstruction instruction = new ASL(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BCC 测试指令
     */
    @Test
    public void testBCC() {
        AlgorithmInstruction instruction = new BCC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BCS 测试指令
     */
    @Test
    public void testBCS() {
        AlgorithmInstruction instruction = new BCS(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BEQ 测试指令
     */
    @Test
    public void testBEQ() {
        AlgorithmInstruction instruction = new BEQ(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BIT 测试指令
     */
    @Test
    public void testBIT() {
        AlgorithmInstruction instruction = new BIT(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BMI 测试指令
     */
    @Test
    public void testBMI() {
        AlgorithmInstruction instruction = new BMI(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BNE 测试指令
     */
    @Test
    public void testBNE() {
        AlgorithmInstruction instruction = new BNE(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BPL 测试指令
     */
    @Test
    public void testBPL() {
        AlgorithmInstruction instruction = new BPL(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BRK 测试指令
     */
    @Test
    public void testBRK() {
        AlgorithmInstruction instruction = new BRK(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BVC 测试指令
     */
    @Test
    public void testBVC() {
        AlgorithmInstruction instruction = new BVC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * BVS 测试指令
     */
    @Test
    public void testBVS() {
        AlgorithmInstruction instruction = new BVS(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CLC 测试指令
     */
    @Test
    public void testCLC() {
        AlgorithmInstruction instruction = new CLC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CLD 测试指令
     */
    @Test
    public void testCLD() {
        AlgorithmInstruction instruction = new CLD(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CLI 测试指令
     */
    @Test
    public void testCLI() {
        AlgorithmInstruction instruction = new CLI(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CLI 测试指令
     */
    @Test
    public void testCLV() {
        AlgorithmInstruction instruction = new CLV(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CMP 测试指令
     */
    @Test
    public void testCMP() {
        AlgorithmInstruction instruction = new CMP(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CPX 测试指令
     */
    @Test
    public void testCPX() {
        AlgorithmInstruction instruction = new CPX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * CPY 测试指令
     */
    @Test
    public void testCPY() {
        AlgorithmInstruction instruction = new CPY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * DEC 测试指令
     */
    @Test
    public void testDEC() {
        AlgorithmInstruction instruction = new DEC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * DEX 测试指令
     */
    @Test
    public void testDEX() {
        AlgorithmInstruction instruction = new DEX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * DEY 测试指令
     */
    @Test
    public void testDEY() {
        AlgorithmInstruction instruction = new DEY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * EOR 测试指令
     */
    @Test
    public void testEOR() {
        AlgorithmInstruction instruction = new EOR(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * INC 测试指令
     */
    @Test
    public void testINC() {
        AlgorithmInstruction instruction = new INC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * INX 测试指令
     */
    @Test
    public void testINX() {
        AlgorithmInstruction instruction = new INX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * INY 测试指令
     */
    @Test
    public void testINY() {
        AlgorithmInstruction instruction = new INY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * JMP 测试指令
     */
    @Test
    public void testJMP() {
        AlgorithmInstruction instruction = new JMP(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * JSR 测试指令
     */
    @Test
    public void testJSR() {
        AlgorithmInstruction instruction = new JSR(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * LDA 测试指令
     */
    @Test
    public void testLDA() {
        AlgorithmInstruction instruction = new LDA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * LDX 测试指令
     */
    @Test
    public void testLDX() {
        AlgorithmInstruction instruction = new LDX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * LDY 测试指令
     */
    @Test
    public void testLDY() {
        AlgorithmInstruction instruction = new LDY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * LSR 测试指令
     */
    @Test
    public void testLSR() {
        AlgorithmInstruction instruction = new LSR(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * NOP 测试指令
     */
    @Test
    public void testNOP() {
        AlgorithmInstruction instruction = new NOP(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * ORA 测试指令
     */
    @Test
    public void testORA() {
        AlgorithmInstruction instruction = new ORA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * PHA 测试指令
     */
    @Test
    public void testPHA() {
        AlgorithmInstruction instruction = new PHA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * PHP 测试指令
     */
    @Test
    public void testPHP() {
        AlgorithmInstruction instruction = new PHP(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * PLA 测试指令
     */
    @Test
    public void testPLA() {
        AlgorithmInstruction instruction = new PLA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * PLP 测试指令
     */
    @Test
    public void testPLP() {
        AlgorithmInstruction instruction = new PLP(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * ROL 测试指令
     */
    @Test
    public void testROL() {
        AlgorithmInstruction instruction = new ROL(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * ROR 测试指令
     */
    @Test
    public void testROR() {
        AlgorithmInstruction instruction = new ROR(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * RTI 测试指令
     */
    @Test
    public void testRTI() {
        AlgorithmInstruction instruction = new RTI(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * RTS 测试指令
     */
    @Test
    public void testRTS() {
        AlgorithmInstruction instruction = new RTS(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * SBC 测试指令
     */
    @Test
    public void testSBC() {
        AlgorithmInstruction instruction = new SBC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * SEC 测试指令
     */
    @Test
    public void testSEC() {
        AlgorithmInstruction instruction = new SEC(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * SED 测试指令
     */
    @Test
    public void testSED() {
        AlgorithmInstruction instruction = new SED(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * SEI 测试指令
     */
    @Test
    public void testSEI() {
        AlgorithmInstruction instruction = new SEI(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * STA 测试指令
     */
    @Test
    public void testSTA() {
        AlgorithmInstruction instruction = new STA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * STX 测试指令
     */
    @Test
    public void testSTX() {
        AlgorithmInstruction instruction = new STX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * STY 测试指令
     */
    @Test
    public void testSTY() {
        AlgorithmInstruction instruction = new STY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TAX 测试指令
     */
    @Test
    public void testTAX() {
        AlgorithmInstruction instruction = new TAX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TAY 测试指令
     */
    @Test
    public void testTAY() {
        AlgorithmInstruction instruction = new TAY(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TSX 测试指令
     */
    @Test
    public void testTSX() {
        AlgorithmInstruction instruction = new TSX(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TXA 测试指令
     */
    @Test
    public void testTXA() {
        AlgorithmInstruction instruction = new TXA(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TXS 测试指令
     */
    @Test
    public void testTXS() {
        AlgorithmInstruction instruction = new TXS(cpu);
        instruction.calculate();
        println(instruction);
    }

    /**
     * TYA 测试指令
     */
    @Test
    public void testTYA() {
        AlgorithmInstruction instruction = new TYA(cpu);
        instruction.calculate();
        println(instruction);
    }

    public static void println(AlgorithmInstruction instruction) {
        System.out.println(instruction.getAliasName());
        System.out.println(instruction.getOperationalData());
        assertEquals(instruction.getClass().getSimpleName(), instruction.getAliasName());
        assertEquals(instruction.getClass().getSimpleName(), instruction.getCode());
    }

}
