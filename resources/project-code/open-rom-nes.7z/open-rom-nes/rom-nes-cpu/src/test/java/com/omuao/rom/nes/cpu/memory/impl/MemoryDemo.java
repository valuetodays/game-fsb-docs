package com.omuao.rom.nes.cpu.memory.impl;

import com.omuao.rom.nes.common.exception.MemoryIOException;
import com.omuao.rom.nes.common.model.memory.Memory;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import static org.junit.Assert.assertEquals;

/**
 * 内存测试
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class MemoryDemo {

    @Rule
    public ExpectedException thrown = ExpectedException.none();

    private static Memory memory;

    @Before
    public void init() {
        int data[] = new int[0xFF];
        data[2] = 4;
        memory = new CPUMemoryImpl(data);
        memory.setWritable(true);
        memory.setReadable(true);
    }

    /**
     * 测试写
     */
    @Test
    public void testRead() {
        assertEquals(4, memory.read(2));
    }

    /**
     * 测试写
     */
    @Test
    public void testWrite() {
        memory.write(2, 3);
        assertEquals(3, memory.read(2));
    }

    /**
     * 测试只读内存
     */
    @Test
    public void testNotRead() {
        memory.setReadable(false);
        thrown.expect(MemoryIOException.class);
        memory.read(2);
        assertEquals(false, memory.readOnly());
        assertEquals(true, memory.writeOnly());
    }

    /**
     * 测试只读内存
     */
    @Test
    public void testNotWrite() {
        memory.setWritable(false);
        thrown.expect(MemoryIOException.class);
        memory.write(2, 3);
        assertEquals(true, memory.readOnly());
        assertEquals(false, memory.writeOnly());
        assertEquals(4, memory.read(2));
    }
}
