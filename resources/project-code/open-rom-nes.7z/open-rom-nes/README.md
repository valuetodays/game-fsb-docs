# open-rom-nes

#### 介绍
NES游戏镜像解析，分析NES镜像文件，获得NES游戏镜像的相关信息。


支持文件格式： INES INES2.0

支持VROM 提取（GraphicsRom） 提取图片。

支持自定义数据渲染。


#### 使用方法

```
        //需自行下载NES 文件镜像测试

        NesFile nesFile = new NesFile("roms/mario.nes");

        //获得MMC类型
        System.out.println(nesFile.getMapperType());

        //获得MMC类型的名字
        System.out.println(nesFile.getMapperTypeName());

        //镜像是否包含金手指
        System.out.println(nesFile.isHaveTrainer());

        //镜像是否为垂直镜像
        System.out.println(nesFile.isVerticalImage());

        //获得程序镜像的数量
        System.out.println(nesFile.getRom().getProgramRomCount());

        //获得图形镜像的数量
        System.out.println(nesFile.getRom().getGraphicsRomCount());

        //NES 文件大小
        System.out.println(nesFile.length());

        //是否为 INES2.0 格式
        System.out.println(nesFile.isNes2Rom());


        //NES 文件2.0
        NesFile2 nesFile2 = new NesFile2("roms/mario.nes");

        //获得控制台类型名称
        System.out.println(nesFile2.getConsoleTypeName());

        //获得硬件名称
        System.out.println(nesFile2.getHardwareName());

        //获得PPU 类型名称
        System.out.println(nesFile2.getPpuName());

        //获得扩展设备名称
        System.out.println(nesFile2.getExpansionDeviceName());

        //获得CPU/PPU 时序类型名称
        System.out.println(nesFile2.getTimingTypeName());
```

字模数据打印


```
        // A 字模的数据
        int[] data = new int[]{
                0x1c, 0x36, 0x63, 0x63, 0x7f, 0x63, 0x63, 0x00,  //模型数据
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00   //辅助配色数据
        };

        //创建格子（Tile）
        GridImpl grid = new GridImpl(data);

        //获得格子的渲染图像
        BufferedImage image = grid.getRenderingImage();

        //创建输出流
        FileOutputStream fos = new FileOutputStream("test3.png");

        //输出图像
        ImageIO.write(image, "png", fos);

        fos.close();
```

提取CHR-ROM 中的图像


```
        //需自行下载NES 文件镜像测试
        //创建NES 文件
        NesFile nesFile = new NesFile("roms/mario.nes");

        //载入镜像
        nesFile.loadRom();

        //获得图像ROM 数据Bank
        int[] graphicsRom = nesFile.getRom().getGraphicsRoms()[0];

        //创建绘制表
        GraphicsTable graphicsTable = new GraphicsTableImpl();
        
        //根据图像ROM创建绘制表
        graphicsTable.valueOfGraphicsRom(graphicsRom);

        //绘制CHR 图像
        BufferedImage image = graphicsTable.getRenderingImage();

        //创建输出流
        FileOutputStream fos = new FileOutputStream("chr.png");

        //输出图像
        ImageIO.write(image, "png", fos);
        
        fos.close();
```

### NES1.0结构图

![NES1.0结构图](https://images.gitee.com/uploads/images/2019/0709/172856_6b227144_1183052.png "NES.png")

### NES2.0结构图

![NES2.0结构图](https://images.gitee.com/uploads/images/2019/0709/172942_79a61383_1183052.png "NES2.png")


#### MOS6502程序模拟结构说明

![MOS6502程序结构说明](https://images.gitee.com/uploads/images/2019/0923/130213_1e23cc8f_1183052.png "CPU结构.png")

