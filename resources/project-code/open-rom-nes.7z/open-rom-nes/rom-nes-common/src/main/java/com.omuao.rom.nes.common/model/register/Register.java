package com.omuao.rom.nes.common.model.register;

import com.omuao.rom.nes.common.model.converter.Converter;

/**
 * 寄存器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface Register<IN, OUT> {

    /**
     * 寄存器名称
     *
     * @return
     */
    String getName();

    /**
     * 设置寄存器名称
     *
     * @param name 名称
     */
    void setName(String name);

    /**
     * 获得输出值
     *
     * @return 输出
     */
    OUT getValue();

    /**
     * 设置值
     *
     * @param in 输入
     */
    void setValue(IN in);

    /**
     * 获得转换器
     *
     * @return 转换器
     */
    Converter getConverter();

    /**
     * 设置转换器
     *
     * @param converter 转换器
     */
    void setConverter(Converter converter);

}