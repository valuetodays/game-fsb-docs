package com.omuao.rom.nes.common.rom;

import com.omuao.rom.nes.common.model.device.Device;

/**
 * NES 文件镜像
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public interface NesFileRom extends Device{

    /**
     * 获得NES文件标识
     *
     * @return
     */
    int[] getFileTag();

    /**
     * 获得程序镜像数目
     */
    int getProgramRomCount();

    /**
     * 获得图形镜像数目
     */
    int getGraphicsRomCount();

    /**
     * 获得屏幕布局相关配置信息
     *
     * @return
     */
    int getScreenConfig();

    /**
     * 获得内存镜像相关配置信息
     *
     * @return
     */
    int getMemoryConfig();

    /**
     * 获得电视相关配置信息
     *
     * @return
     */
    int getTvConfig();

    /**
     * 获得其他相关配置信息
     *
     * @return
     */
    int getOtherConfig();

    /**
     * 获得其他相关配置信息
     *
     * @return
     */
    int[] getAllConfigs();

    /**
     * 图形ROM区
     *
     * @return
     */
    int[][] getGraphicsRoms();

    /**
     * 程序ROM区
     *
     * @return
     */
    int[][] getProgramRoms();

    /**
     * 金手指数据区
     *
     * @return
     */
    int[] getTrainerData();

    /**
     * 获得头部数据
     */
    int[] getHeaders();
}
