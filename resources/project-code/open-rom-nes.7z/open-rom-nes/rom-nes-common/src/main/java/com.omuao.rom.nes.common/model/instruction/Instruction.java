package com.omuao.rom.nes.common.model.instruction;

import java.util.List;

/**
 * 指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface Instruction {

    /**
     * 指令编码
     *
     * @return 编码
     */
    String getCode();

    /**
     * 设置指令编码
     *
     * @param code 编码
     */
    void setCode(String code);

    /**
     * 获得编码别名
     *
     * @return 编码别名
     */
    String getAliasName();

    /**
     * 设置指令别名
     *
     * @param aliasName 指令别名
     */
    void setAliasName(String aliasName);

    /**
     * 当前获取指令长度 字节
     */
    int length();

    /**
     * 获取当前指令的周期
     *
     * @return
     */
    int getClock();

    /**
     * 设置当前指令的周期
     *
     * @param clock 周期
     * @return
     */
    void setClock(int clock);

    /**
     * 获取当前执行的指令信息
     *
     * @return
     */
    InstructionInfo getInstructionInfo();

    /**
     * 当前执行的机器码
     *
     * @return 机器码
     */
    String machineCode();

    /**
     * 当前的寻址模式
     *
     * @return 寻址模式
     */
    String addressMode();

    /**
     * 获取指令内容
     *
     * @return
     */
    List<InstructionInfo> getInstructionContents();

    /**
     * 设置指令内容
     *
     * @param instructionContents 指令内容
     */
    void setInstructionContents(List<InstructionInfo> instructionContents);
}