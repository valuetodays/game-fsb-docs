package com.omuao.rom.nes.common.enums;

/**
 * NES TV系统常量
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public enum NesTvSystem {

    NTSC(0x00, 113.6666666666666667f, 28.3333333333333333f, 2273.3333333333333333f, 29780.5f, 3f, 513f, 513f),
    PAL(0x01, 106.5625f, 26.5625f, 7459.375f, 33247.5f, 3.2f, 513f, 513f),
    DENDY(0x02, 113.6666666666666667f, 28.3333333333333333f, 2273.3333333333333333f, 35464f, 3f, 513f, 513f);

    NesTvSystem(int value, float scanLine, float hBlank, float nmiStartOfRendering, float frame, float ppuDotsPerCpuCycle, float oam, float dam) {
        this.value = value;
        this.scanLine = scanLine;
        this.hBlank = hBlank;
        this.nmiStartOfRendering = nmiStartOfRendering;
        this.frame = frame;
        this.ppuDotsPerCpuCycle = ppuDotsPerCpuCycle;
        this.oam = oam;
        this.dam = dam;
    }

    /**
     * 值
     */
    private int value;

    /**
     * 扫描线
     */
    private float scanLine;

    /**
     * H Blank
     */
    private float hBlank;

    /**
     * NMI开始渲染
     */
    private float nmiStartOfRendering;

    /**
     * 帧
     */
    private float frame;

    /**
     * 每个CPU周期的PPU点
     */
    private float ppuDotsPerCpuCycle;

    /**
     * OAM
     */
    private float oam;

    /**
     * DAM
     */
    private float dam;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public float getScanLine() {
        return scanLine;
    }

    public void setScanLine(float scanLine) {
        this.scanLine = scanLine;
    }

    public float gethBlank() {
        return hBlank;
    }

    public void sethBlank(float hBlank) {
        this.hBlank = hBlank;
    }

    public float getNmiStartOfRendering() {
        return nmiStartOfRendering;
    }

    public void setNmiStartOfRendering(float nmiStartOfRendering) {
        this.nmiStartOfRendering = nmiStartOfRendering;
    }

    public float getFrame() {
        return frame;
    }

    public void setFrame(float frame) {
        this.frame = frame;
    }

    public float getPpuDotsPerCpuCycle() {
        return ppuDotsPerCpuCycle;
    }

    public void setPpuDotsPerCpuCycle(float ppuDotsPerCpuCycle) {
        this.ppuDotsPerCpuCycle = ppuDotsPerCpuCycle;
    }

    public float getOam() {
        return oam;
    }

    public void setOam(float oam) {
        this.oam = oam;
    }

    public float getDam() {
        return dam;
    }

    public void setDam(float dam) {
        this.dam = dam;
    }

    public static NesTvSystem valueOf(int type) {
        for (NesTvSystem tvSystem : NesTvSystem.values()) {
            if (tvSystem.getValue() == type) {
                return tvSystem;
            }
        }
        return null;
    }

    @Override
    public String toString() {
        return "NesTvSystem{" +
                "value=" + value +
                ", scanLine=" + scanLine +
                ", hBlank=" + hBlank +
                ", nmiStartOfRendering=" + nmiStartOfRendering +
                ", frame=" + frame +
                ", ppuDotsPerCpuCycle=" + ppuDotsPerCpuCycle +
                ", oam=" + oam +
                ", dam=" + dam +
                '}';
    }
}
