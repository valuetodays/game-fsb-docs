package com.omuao.rom.nes.common.model.graphics;

import com.omuao.rom.nes.common.model.graphics.Color;

/**
 * 调色板（Title）
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public interface Palette {

    void init(int size);

    void setColors(Color[] colors);

    Color[] getColors();
    
    Color getColor(int index);

    void setColor(int index, int argb);

}
