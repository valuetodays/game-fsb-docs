package com.omuao.rom.nes.common.exception;

/**
 * 模拟器运行时异常
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class EmulatorRuntimeException extends RuntimeException {

    public EmulatorRuntimeException() {
    }

    public EmulatorRuntimeException(String message) {
        super(message);
    }

    public EmulatorRuntimeException(String message, Throwable cause) {
        super(message, cause);
    }

    public EmulatorRuntimeException(Throwable cause) {
        super(cause);
    }

}
