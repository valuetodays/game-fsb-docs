package com.omuao.rom.nes.common.model.device;

/**
 * 设备信息
 *
 * @author yumi@oumao.com
 * @since 2019-09-25
 **/
public interface DeviceInfo {
    

}