package com.omuao.rom.nes.common.model.instruction.impl;

import com.omuao.rom.nes.common.model.instruction.InstructionSet;

import java.util.HashSet;

/**
 * 指令集
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public abstract class AbstractInstructionSet extends HashSet implements InstructionSet {

    /**
     * 指令集别名
     */
    private String aliasName;

    @Override
    public String getAliasName() {
        return this.aliasName;
    }

    @Override
    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }
}
