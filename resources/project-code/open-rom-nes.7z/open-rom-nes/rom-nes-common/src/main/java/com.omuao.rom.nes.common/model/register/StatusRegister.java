package com.omuao.rom.nes.common.model.register;

import java.util.Map;

/**
 * 状态寄存器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface StatusRegister<IN, OUT> extends Register<IN, OUT> {

    /**
     * 获得状态Map
     *
     * @return 状态MAP
     */
    Map<String, Boolean> getStatusMap();

    /**
     * 根据 KEY 获得 状态值
     *
     * @param key 键
     * @return 状态值
     */
    Boolean getStatus(String key);

    /**
     * 初始化KEY 为 false
     *
     * @param key 键
     */
    void initStatus(String key);

    /**
     * 初始化 KEY 为指定值
     *
     * @param key   键
     * @param value 值
     */
    void initStatus(String key, Boolean value);

}
