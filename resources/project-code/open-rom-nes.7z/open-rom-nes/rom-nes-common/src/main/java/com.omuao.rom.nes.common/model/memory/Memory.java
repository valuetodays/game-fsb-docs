package com.omuao.rom.nes.common.model.memory;

import com.omuao.rom.nes.common.model.device.Device;

/**
 * 内存
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public interface Memory extends Device{

    /**
     * 根据地址读取内存
     *
     * @param address 地质
     * @return 内存内容
     */
    int read(int address);

    /**
     * 根据地址写入内容
     *
     * @param address 地址
     * @param data    数据内容
     */
    void write(int address, int data);

    /**
     * 只读
     *
     * @return
     */
    boolean readOnly();

    /**
     * 只写
     *
     * @return
     */
    boolean writeOnly();

    /**
     * 设置数据总线位数
     *
     * @param dataBusBit 数据总线位数
     */
    void setDataBusBit(int dataBusBit);

    /**
     * 获得数据总线位数
     *
     * @return 数据总线位数
     */
    int getDataBusBit();

    /**
     * 获得数据总线
     *
     * @return 数据总线
     */
    int getIntDataBus();

    /**
     * 可写
     *
     * @param writable 写
     */
    void setWritable(boolean writable);

    /**
     * 可读
     *
     * @param readable 读
     */
    void setReadable(boolean readable);
}
