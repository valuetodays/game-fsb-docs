package com.omuao.rom.nes.common.rom.impl;

import com.omuao.rom.nes.common.model.device.DeviceType;
import com.omuao.rom.nes.common.rom.NesFile2Rom;
import com.omuao.rom.nes.common.rom.NesFileRom;

import java.util.ArrayList;

/**
 * NES2.0 文件镜像实现类
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFile2RomImpl extends NesFileRomImpl implements NesFile2Rom {

    /**
     * 其它ROM数量
     */
    private int miscellaneousRomCount;

    /**
     * 其它ROM
     */
    private int[][] miscellaneousRoms;

    public NesFile2RomImpl() {
        this.setDeviceName("NES 2.0 ROM");
        this.setDeviceCode("NES 2.0 ROM");
    }

    @Override
    public int getMiscellaneousRomCount() {
        return miscellaneousRomCount;
    }

    public void setMiscellaneousRomCount(int miscellaneousRomCount) {
        this.miscellaneousRomCount = miscellaneousRomCount;
    }

    @Override
    public int[][] getMiscellaneousRoms() {
        return miscellaneousRoms;
    }

    public void setMiscellaneousRoms(int[][] miscellaneousRoms) {
        this.miscellaneousRoms = miscellaneousRoms;
    }

    public NesFile2RomImpl valueOf(NesFileRom rom) {
        if (rom == null) {
            return this;
        }
        this.setAllConfigs(rom.getAllConfigs());
        this.setFileTag(rom.getFileTag());
        this.setGraphicsRomCount(rom.getGraphicsRomCount());
        this.setGraphicsRoms(rom.getGraphicsRoms());
        this.setHeaders(rom.getHeaders());
        this.setMemoryConfig(rom.getMemoryConfig());
        this.setOtherConfig(rom.getOtherConfig());
        this.setProgramRomCount(rom.getProgramRomCount());
        this.setProgramRoms(rom.getProgramRoms());
        this.setScreenConfig(rom.getScreenConfig());
        this.setTrainerData(rom.getTrainerData());
        this.setTvConfig(rom.getTvConfig());
        return this;
    }
}
