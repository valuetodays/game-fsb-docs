package com.omuao.rom.nes.common.model.graphics;

import java.awt.image.BufferedImage;

/**
 * 格子（Title）
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public interface Grid {

    /**
     * 获得渲染图像
     *
     * @return
     */
    BufferedImage getRenderingImage();

    /**
     * 获得渲染图
     *
     * @param reversal 反转
     * @return
     */
    BufferedImage getRenderingImage(boolean reversal);

    /**
     * 设置调色板
     *
     * @param palette 调色板
     */
    void setPalette(Palette palette);

    /**
     * 获得调色板
     *
     * @return 调色板
     */
    Palette getPalette();

}
