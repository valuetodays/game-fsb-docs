package com.omuao.rom.nes.common.enums;

/**
 * PPU 版本类型
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum PPUType {

    PPU_TYPE_00(0x00, "RP2C03B"),
    PPU_TYPE_01(0x01, "RP2C03G"),
    PPU_TYPE_02(0x02, "RP2C04-0001"),
    PPU_TYPE_03(0x03, "RP2C04-0002"),
    PPU_TYPE_04(0x04, "RP2C04-0003"),
    PPU_TYPE_05(0x05, "RP2C04-0004"),
    PPU_TYPE_06(0x06, "RC2C03B"),
    PPU_TYPE_07(0x07, "RC2C03C"),
    PPU_TYPE_08(0x08, "RC2C05-01 ($2002 AND $?? =$1B)"),
    PPU_TYPE_09(0x09, "RC2C05-02 ($2002 AND $3F =$3D)"),
    PPU_TYPE_0A(0x0A, "RC2C05-03 ($2002 AND $1F =$1C)"),
    PPU_TYPE_0B(0x0B, "RC2C05-04 ($2002 AND $1F =$1B)"),
    PPU_TYPE_0C(0x0C, "RC2C05-05 ($2002 AND $1F =unknown)"),
    PPU_TYPE_0D(0x0D, "reserved"),
    PPU_TYPE_0E(0x0E, "reserved"),
    PPU_TYPE_0F(0x0F, "reserved");

    /**
     * 控制台类型值
     */
    private int value;

    /**
     * 控制台名称
     */
    private String name;

    PPUType(int value, String name) {

        this.value = value;

        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static PPUType valueOf(int type) {
        for (PPUType ppuType : PPUType.values()) {
            if (ppuType.getValue() == type) {
                return ppuType;
            }
        }
        return null;
    }
}
