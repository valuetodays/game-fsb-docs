package com.omuao.rom.nes.common.constant;

/**
 * 资源常量
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class RC {

    /**
     * 电视NTSC制式
     */
    public static final float TV_NTSC_HZ = 1.7897725f;

    /**
     * 电视PAL制式
     */
    public static final float TV_PAL_HZ = 1.773447f;

}
