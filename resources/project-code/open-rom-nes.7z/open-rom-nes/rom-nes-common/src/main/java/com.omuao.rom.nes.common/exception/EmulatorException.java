package com.omuao.rom.nes.common.exception;

/**
 * 模拟器异常
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class EmulatorException extends Exception {

    public EmulatorException() {
    }

    public EmulatorException(String message) {
        super(message);
    }

    public EmulatorException(String message, Throwable cause) {
        super(message, cause);
    }

    public EmulatorException(Throwable cause) {
        super(cause);
    }

}
