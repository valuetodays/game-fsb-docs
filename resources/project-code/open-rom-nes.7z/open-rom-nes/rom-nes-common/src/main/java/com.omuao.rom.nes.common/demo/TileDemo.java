package com.omuao.rom.nes.common.demo;

import com.omuao.rom.nes.common.model.graphics.impl.GridImpl;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 字模数据测试代码
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class TileDemo {

    public static void main(String[] args) throws IOException {

        // A 字母的数据
        int[] data = new int[]{
                0x1c, 0x36, 0x63, 0x63, 0x7f, 0x63, 0x63, 0x00,
                0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        };

        GridImpl grid = new GridImpl(data);
        BufferedImage image = grid.getRenderingImage(true);


        FileOutputStream fos = new FileOutputStream("test3.png");

        ImageIO.write(image, "png", fos);
        fos.close();

    }

}
