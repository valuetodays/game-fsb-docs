package com.omuao.rom.nes.common.exception;

/**
 * NES 文件异常
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFileException extends RuntimeException {

    public NesFileException() {
    }

    public NesFileException(String message) {
        super(message);
    }

    public NesFileException(String message, Throwable cause) {
        super(message, cause);
    }

    public NesFileException(Throwable cause) {
        super(cause);
    }
}
