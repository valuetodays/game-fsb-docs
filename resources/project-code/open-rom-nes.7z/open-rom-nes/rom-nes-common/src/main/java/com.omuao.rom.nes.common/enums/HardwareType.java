package com.omuao.rom.nes.common.enums;

/**
 * 硬件类型
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum HardwareType {

    HARDWARE_TYPE_00(0x00, "Unisystem (normal)"),
    HARDWARE_TYPE_01(0x01, "Unisystem (RBI Baseball protection)"),
    HARDWARE_TYPE_02(0x02, "Unisystem (TKO Boxing protection)"),
    HARDWARE_TYPE_03(0x03, "Unisystem (Super Xevious protection)"),
    HARDWARE_TYPE_04(0x04, "Unisystem (Vs. Ice Climber Japan protection)"),
    HARDWARE_TYPE_05(0x05, "Dual System (normal)"),
    HARDWARE_TYPE_06(0x06, "Dual System (Raid on Bungeling Bay protection)");

    /**
     * 控制台类型值
     */
    private int value;

    /**
     * 控制台名称
     */
    private String name;

    HardwareType(int value, String name) {

        this.value = value;

        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static HardwareType valueOf(int type) {
        for (HardwareType hardwareType : HardwareType.values()) {
            if (hardwareType.getValue() == type) {
                return hardwareType;
            }
        }
        return null;
    }
}
