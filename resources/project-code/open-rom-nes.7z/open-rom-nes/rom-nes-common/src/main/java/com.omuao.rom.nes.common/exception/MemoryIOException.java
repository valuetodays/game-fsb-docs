package com.omuao.rom.nes.common.exception;

import java.io.IOException;

/**
 * 内存IO 异常
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class MemoryIOException extends RuntimeException {

    public MemoryIOException() {
    }

    public MemoryIOException(String message) {
        super(message);
    }

    public MemoryIOException(String message, Throwable cause) {
        super(message, cause);
    }

    public MemoryIOException(Throwable cause) {
        super(cause);
    }
}
