package com.omuao.rom.nes.common.model.converter;

import com.omuao.rom.nes.common.exception.ConverterException;

/**
 * 转换器
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface Converter<IN, OUT> {

    /**
     * 转换数据
     *
     * @param in 输入数据
     * @return 输出数据
     * @throws ConverterException 转换异常
     */
    OUT convert(IN in) throws ConverterException;

}
