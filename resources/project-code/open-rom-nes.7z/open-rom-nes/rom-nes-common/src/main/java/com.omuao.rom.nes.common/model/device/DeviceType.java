package com.omuao.rom.nes.common.model.device;

/**
 * 设备类型
 *
 * @author yumi@oumao.com
 * @since 2019-09-25
 **/
public enum DeviceType {

    MEMORY,//内存设备
    PROCESSOR,//处理器设备
    HARD_DISK,//硬件设备
    MONITOR,//显示器设备
    KEYBOARD,//键盘设备
    MEDIA_CONTROL,//音乐、视频、相关设备
    MOUSE,//鼠标设备
    NETWORK_ADAPTER//网络适配器

}
