package com.omuao.rom.nes.common.utils;

/**
 * 颜色工具类
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class ColorUtils {

    public static int getRgb(int a, int r, int g, int b) {
        r = r & 0xff;
        g = g & 0xff;
        b = g & 0xff;
        return (r << 16) | (r << 8) | b;
    }

    public static int getArgb(int a, int r, int g, int b) {
        r = r & 0xff;
        g = g & 0xff;
        b = g & 0xff;
        a = a & 0xff;
        return (a << 24) | (r << 16) | (r << 8) | b;
    }

    public static int getNoAlphaArgb(int r, int g, int b) {
        return getArgb(0xff, r, g, b);
    }


}
