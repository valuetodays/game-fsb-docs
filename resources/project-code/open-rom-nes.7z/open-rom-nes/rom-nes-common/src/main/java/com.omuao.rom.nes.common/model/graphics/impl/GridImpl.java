package com.omuao.rom.nes.common.model.graphics.impl;

import com.omuao.rom.nes.common.enums.Colors;
import com.omuao.rom.nes.common.model.graphics.Color;
import com.omuao.rom.nes.common.model.graphics.Grid;
import com.omuao.rom.nes.common.model.graphics.Palette;

import java.awt.image.BufferedImage;

/**
 * 格子（Title）
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class GridImpl implements Grid {

    /**
     * 数据
     */
    private int[] data;

    /**
     * 调色板
     */
    private Palette palette;

    public GridImpl() {
    }

    public GridImpl(int[] data) {
        this.data = data;
        init();
    }

    private void init() {
        if (this.data == null) {
            return;
        }
    }

    @Override
    public BufferedImage getRenderingImage() {

        return getRenderingImage(false);
    }

    @Override
    public BufferedImage getRenderingImage(boolean reversal) {
        BufferedImage image = new BufferedImage(8, 8, BufferedImage.TYPE_4BYTE_ABGR);

        for (int row = 0; row < 8; row++) {
            fillImageData(row, image, reversal);
        }
        return image;
    }

    /**
     * 填充图像数据
     *
     * @param row   行数
     * @param image 图像
     */
    private void fillImageData(int row, BufferedImage image, boolean reversal) {
        int[] palette = this.getPaletteData();
        int[] matrix = this.getMatrixData();
        int[] pixels = convertData(matrix[row], reversal);
        int[] colorPixels = convertData(palette[row], reversal);
        for (int index = 0; index < pixels.length; index++) {
            int color = colorPixels[index];
            int model = pixels[index];
            int paletteIndex = model << 1 | color;
            Color paletteColor = this.getPalette().getColor(paletteIndex);
            image.setRGB(index, row, paletteColor.getArgb());
        }
    }

    /**
     * 转换数据为像素
     *
     * @param data 数据
     * @return
     */
    private int[] convertData(int data, boolean reversal) {
        int[] pixel = new int[8];

        int tempData = data & 0xff;
        for (int i = 0; i < pixel.length; i++) {
            if (reversal) {
                pixel[i] = (tempData >> (7 - i)) & 1;
                continue;
            }
            pixel[i] = (tempData >> i) & 1;
        }
        return pixel;
    }

    public int[] getPaletteData() {
        int[] palette = new int[8];
        int counter = 0;
        for (int i = 8; i < 16; i++) {
            palette[counter] = data[i];
            counter++;
        }
        return palette;
    }

    public int[] getMatrixData() {
        int[] matrix = new int[8];
        int counter = 0;
        for (int i = 0; i < 8; i++) {
            matrix[counter] = data[i];
            counter++;
        }
        return matrix;
    }


    public int[] getData() {
        return data;
    }

    public void setData(int[] data) {
        this.data = data;
        init();
    }

    @Override
    public Palette getPalette() {
        if (palette == null) {
            palette = new NesPaletteImpl();
            palette.setColors(new Color[]{
                    Colors.BLACK.getColor(),
                    Colors.BLUE.getColor(),
                    Colors.WHITE.getColor(),
                    Colors.RED.getColor()
            });
        }
        return palette;
    }

    @Override
    public void setPalette(Palette palette) {
        this.palette = palette;
    }
}
