package com.omuao.rom.nes.common.demo;

import com.omuao.rom.nes.common.io.NesFile;
import com.omuao.rom.nes.common.io.NesFile2;

import java.io.IOException;

/**
 * 测试代码。
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFileDemo {

    public static void main(String[] args) throws IOException {

        //需自行下载NES 文件镜像测试
        NesFile nesFile = new NesFile("roms/mario.nes");

        System.out.println(nesFile.getMapperType());

        System.out.println(nesFile.getMapperTypeName());

        System.out.println(nesFile.isHaveTrainer());

        System.out.println(nesFile.isVerticalImage());

        System.out.println(nesFile.getRom().getProgramRomCount());

        System.out.println(nesFile.getRom().getGraphicsRomCount());

        System.out.println(nesFile.length());

        System.out.println(nesFile.isNes2Rom());

        System.out.println(nesFile.getNesTvSystem());

        NesFile2 nesFile2 = new NesFile2("roms/mario.nes");

        System.out.println(nesFile2.getConsoleTypeName());

        System.out.println(nesFile2.getHardwareName());

        System.out.println(nesFile2.getPpuName());

        System.out.println(nesFile2.getExpansionDeviceName());

        System.out.println(nesFile2.getTimingTypeName());
    }

}
