package com.omuao.rom.nes.common.demo;

import com.omuao.rom.nes.common.io.NesFile;
import com.omuao.rom.nes.common.model.graphics.GraphicsTable;
import com.omuao.rom.nes.common.model.graphics.impl.GraphicsTableImpl;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * 图形解析代码
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class GraphicsTableDemo {

    public static void main(String[] args) throws IOException {

        //需自行下载NES 文件镜像测试
        NesFile nesFile = new NesFile("roms/mario.nes");
        nesFile.loadRom();
        int[] graphicsRom = nesFile.getRom().getGraphicsRoms()[0];

        GraphicsTable graphicsTable = new GraphicsTableImpl();
        graphicsTable.valueOfGraphicsRom(graphicsRom);

        BufferedImage image = graphicsTable.getRenderingImage(true,true);

        FileOutputStream fos = new FileOutputStream("chr.png");

        ImageIO.write(image, "png", fos);
        fos.close();

    }
}
