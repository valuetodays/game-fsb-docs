package com.omuao.rom.nes.common.model.graphics;

import java.awt.image.BufferedImage;

/**
 * 图形表
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public interface GraphicsTable {

    /**
     * 获得格子
     *
     * @return 格子
     */
    Grid[] getGrids();

    /**
     * 获得渲染图像
     *
     * @return 渲染图像
     */
    BufferedImage getRenderingImage();

    /**
     * 获得渲染图
     *
     * @param reversal 反转
     * @return
     */
    BufferedImage getRenderingImage(boolean reversal);

    /**
     * 获得指定格子宽度的渲染图像
     *
     * @param grids 格子数
     * @return 渲染图像
     */
    BufferedImage getRenderingImage(int grids);

    /**
     * 获得指定格子宽度的渲染图像
     *
     * @param grids    格子数
     * @param reversal 反转
     * @param vertical 垂直
     * @return 渲染图像
     */
    BufferedImage getRenderingImage(int grids, boolean reversal, boolean vertical);

    /**
     * 渲染图像
     *
     * @param reversal 反转
     * @param vertical 垂直
     * @return 渲染图像
     */
    BufferedImage getRenderingImage(boolean reversal, boolean vertical);

    /**
     * 根据图形ROM 创建图形表
     *
     * @param graphicsRom 图形ROM
     */
    void valueOfGraphicsRom(int[] graphicsRom);
}