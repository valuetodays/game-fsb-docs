package com.omuao.rom.nes.common.enums;

/**
 * 扩展控制台类型
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum ExtendedConsoleType {
    EXTENDED_CONSOLE_TYPE_00(0x00, "Regular NES/Famicom/Dendy"),
    EXTENDED_CONSOLE_TYPE_01(0x01, "Nintendo Vs. System"),
    EXTENDED_CONSOLE_TYPE_02(0x02, "Nintendo Playchoice 10"),
    EXTENDED_CONSOLE_TYPE_03(0x03, "Regular Famiclone, but with CPU that supports Decimal Mode (e.g. Bit Corporation Creator)"),
    EXTENDED_CONSOLE_TYPE_04(0x04, "V.R. Technology VT01 with monochrome palette"),
    EXTENDED_CONSOLE_TYPE_05(0x05, "V.R. Technology VT01 with red/cyan STN palette"),
    EXTENDED_CONSOLE_TYPE_06(0x06, "V.R. Technology VT02"),
    EXTENDED_CONSOLE_TYPE_07(0x07, "V.R. Technology VT03"),
    EXTENDED_CONSOLE_TYPE_08(0x08, "V.R. Technology VT09"),
    EXTENDED_CONSOLE_TYPE_09(0x09, "V.R. Technology VT32"),
    EXTENDED_CONSOLE_TYPE_0A(0x0A, "V.R. Technology VT369"),
    EXTENDED_CONSOLE_TYPE_0B(0x0B, "reserved"),
    EXTENDED_CONSOLE_TYPE_0C(0x0C, "reserved"),
    EXTENDED_CONSOLE_TYPE_0D(0x0D, "reserved"),
    EXTENDED_CONSOLE_TYPE_0E(0x0E, "reserved"),
    EXTENDED_CONSOLE_TYPE_0F(0x0F, "reserved");
    /**
     * 控制台类型值
     */
    private int value;

    /**
     * 控制台名称
     */
    private String name;

    ExtendedConsoleType(int value, String name) {

        this.value = value;

        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static ExtendedConsoleType valueOf(int type) {
        for (ExtendedConsoleType consoleType : ExtendedConsoleType.values()) {
            if (consoleType.getValue() == type) {
                return consoleType;
            }
        }
        return null;
    }

}
