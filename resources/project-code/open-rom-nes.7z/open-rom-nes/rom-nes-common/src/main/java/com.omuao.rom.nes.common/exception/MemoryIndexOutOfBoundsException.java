package com.omuao.rom.nes.common.exception;

/**
 * 内存越界异常
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class MemoryIndexOutOfBoundsException extends ArrayIndexOutOfBoundsException {

    public MemoryIndexOutOfBoundsException() {
    }

    public MemoryIndexOutOfBoundsException(int index) {
        super(index);
    }

    public MemoryIndexOutOfBoundsException(String s) {
        super(s);
    }
}
