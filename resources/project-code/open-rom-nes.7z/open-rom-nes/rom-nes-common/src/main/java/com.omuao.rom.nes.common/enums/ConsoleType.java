package com.omuao.rom.nes.common.enums;

/**
 * 控制台类型
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum ConsoleType {
    CONSOLE_TYPE_0(0, "Nintendo Entertainment System/Family Computer"),
    CONSOLE_TYPE_1(1, "Nintendo Vs. System"),
    CONSOLE_TYPE_2(2, "Nintendo Playchoice 10"),
    CONSOLE_TYPE_3(3, "Extended Console Type");
    /**
     * 控制台类型值
     */
    private int value;

    /**
     * 控制台名称
     */
    private String name;

    ConsoleType(int value, String name) {

        this.value = value;

        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static ConsoleType valueOf(int type) {
        for (ConsoleType consoleType : ConsoleType.values()) {
            if (consoleType.getValue() == type) {
                return consoleType;
            }
        }
        return null;
    }
}
