package com.omuao.rom.nes.common.model.address;

/**
 * 寻址方式
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public abstract class AbstractAddressMode<IN, OUT> implements AddressMode<IN, OUT> {

    /**
     * 寻址方式编码
     */
    private String code;

    /**
     * 寻址方式名称
     */
    private String name;

    @Override
    public String getCode() {
        return code;
    }

    @Override
    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }
}
