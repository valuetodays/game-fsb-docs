package com.omuao.rom.nes.common.model.instruction.impl;

import com.omuao.rom.nes.common.model.instruction.Instruction;
import com.omuao.rom.nes.common.model.instruction.InstructionInfo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 指令实现
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class InstructionImpl implements Instruction {

    /**
     * 指令编码
     */
    private String code;

    /**
     * 指令名称
     */
    private String aliasName;

    /**
     * 机器码
     */
    private List<String> machineCodes;

    /**
     * 指令内容
     */
    private List<InstructionInfo> instructionContents;

    /**
     * 指令周期
     */
    private int clock;

    public InstructionImpl() {
        machineCodes = new ArrayList<>();
        instructionContents = new ArrayList<>();
    }

    @Override
    public String getCode() {
        return this.code;
    }

    @Override
    public void setCode(String code) {
        this.code = code;
    }

    @Override
    public String getAliasName() {
        return this.aliasName;
    }

    @Override
    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

    public List<String> getMachineCodes() {
        return machineCodes;
    }

    public void setMachineCodes(List<String> machineCodes) {
        this.machineCodes = machineCodes;
    }

    /**
     * 根据数组添加指令机器码
     *
     * @param array
     */
    public void addMachineCodeByArray(String[] array) {
        if (array != null) {
            for (String code : array) {
                if (code != null && !"".equals(code)) {
                    machineCodes.add(code);
                }
            }
        }
    }

    /**
     * 根据指令信息数组添加指令信息
     *
     * @param instructionContents 指令数组
     */
    public void addInstructionInfoByArray(InstructionInfo[] instructionContents) {
        if (instructionContents != null) {

            for (InstructionInfo instructionInfo : instructionContents) {
                if (instructionInfo.getMachineCode() != null) {
                    this.instructionContents.add(instructionInfo);
                }
            }
        }
    }

    @Override
    public int length() {
        InstructionInfo instructionInfo = getInstructionInfo();
        if (instructionInfo != null) {
            return instructionInfo.getLength();
        }
        return -1;
    }

    @Override
    public String machineCode() {
        return null;
    }

    @Override
    public InstructionInfo getInstructionInfo() {
        InstructionInfo instructionInfo = findInstructionInfoByMachineCode(machineCode());
        return instructionInfo;
    }

    public InstructionInfo findInstructionInfoByMachineCode(String machineCode) {
        if (machineCode != null) {

            for (InstructionInfo instructionInfo : instructionContents) {
                if (machineCode.equals(instructionInfo.getMachineCode())) {
                    return instructionInfo;
                }
            }
        }
        return null;
    }

    @Override
    public List<InstructionInfo> getInstructionContents() {
        return instructionContents;
    }

    @Override
    public void setInstructionContents(List<InstructionInfo> instructionContents) {
        this.instructionContents = instructionContents;
    }

    @Override
    public String addressMode() {
        return getInstructionInfo().getAddressMode();
    }

    @Override
    public int getClock() {
        return clock;
    }

    @Override
    public void setClock(int clock) {
        this.clock = clock;
    }
}
