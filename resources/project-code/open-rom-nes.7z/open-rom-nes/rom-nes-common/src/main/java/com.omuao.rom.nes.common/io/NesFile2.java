package com.omuao.rom.nes.common.io;

import com.omuao.rom.nes.common.enums.NesTvSystem;
import com.omuao.rom.nes.common.enums.ConsoleType;
import com.omuao.rom.nes.common.enums.ExpansionDevice;
import com.omuao.rom.nes.common.enums.ExtendedConsoleType;
import com.omuao.rom.nes.common.enums.HardwareType;
import com.omuao.rom.nes.common.enums.PPUType;
import com.omuao.rom.nes.common.enums.TimingType;
import com.omuao.rom.nes.common.enums.MMCLibrary;
import com.omuao.rom.nes.common.exception.NesFileException;
import com.omuao.rom.nes.common.rom.impl.NesFile2RomImpl;
import com.omuao.rom.nes.common.rom.impl.NesFileRomImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;

/**
 * NES2.0 文件
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFile2 extends NesFile {
    public NesFile2(String pathname) {
        super(pathname);
        init();
    }

    public NesFile2(String parent, String child) {
        super(parent, child);
        init();
    }

    public NesFile2(File parent, String child) {
        super(parent, child);
        init();
    }

    public NesFile2(URI uri) {
        super(uri);
        init();
    }

    @Override
    void init() {
        super.init();

        if (this.isNes2Rom()) {

            int[] headers = this.getRom().getHeaders();

            // 程序数据块数
            int prgRomsCount = headers[4];
            //高位程序数据块 数量
            int msbPrgRomsCount = headers[9] & 0xf;

            ((NesFileRomImpl) this.getRom()).setProgramRomCount(msbPrgRomsCount << 8 | (prgRomsCount & 0xff));

            // 图案数据块数
            int chrRomsCount = headers[5];

            //高位图案数据块数量
            int msbChrRomsCount = headers[9] >> 4 & 0xf;
            ((NesFileRomImpl) this.getRom()).setGraphicsRomCount(msbChrRomsCount << 8 | (chrRomsCount & 0xff));

        }
    }

    @Override
    public long loadRom() {
        long index = super.loadRom();

        if (this.isNes2Rom()) {

            NesFile2RomImpl rom = new NesFile2RomImpl();

            rom.valueOf(this.getRom());

            FileInputStream in = null;

            try {
                in = new FileInputStream(this);

                in.mark(0);

                in.skip(index);

//                int miscellaneousRomCount = (int) ((length() - index) / 0x4000);
//
//                rom.setMiscellaneousRomCount(miscellaneousRomCount);

                int miscellaneousRomCount = this.getMiscellaneousRomCount();

                int[][] miscellaneousBank = new int[miscellaneousRomCount][];

                for (int romCount = 0; romCount < miscellaneousBank.length; romCount++) {

                    for (int data = 0; data < 0x4000; data++) {
                        miscellaneousBank[romCount][data] = in.read();
                    }
                    index += 0x4000;

                }
                rom.setMiscellaneousRoms(miscellaneousBank);
            } catch (Exception e) {
                throw new NesFileException(e);
            } finally {
                try {
                    in.close();
                } catch (IOException e) {
                    throw new NesFileException(e);
                }
            }
            this.setRom(rom);
        }
        return index;

    }

    @Override
    protected void verifyFile() {
        super.verifyFile();
    }

    /**
     * 获得MapperType 映射MMC类型
     *
     * @return
     */
    public int getMapperType() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return ((headers[8] & 0xf) >> 8) | ((headers[7] & 0xf0) >> 4) | (headers[6] & 0xf0);
    }

    /**
     * 获得Mapper 类型名称
     *
     * @return
     */
    public String getMapperTypeName() {
        verifyFile();
        String name = MMCLibrary.MAPPER_NAME_LIB.get(getMapperType());
        return name == null ? "Misc(Unknown)" : name;
    }

    /**
     * 获得子Mapper类型/编号
     *
     * @return Mapper类型/编号
     */
    public int getSubMapperType() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return (headers[8] & 0xf0) >> 4;
    }

    /**
     * 获得 PPU/CPU 时序类型
     *
     * @return 时序类型
     */
    public int getTimingType() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return (headers[12] & 0x3);
    }

    /**
     * 获得 PPU/CPU 时序类型 名称
     *
     * @return 时序类型名称
     */
    public String getTimingTypeName() {
        verifyFile();
        return TimingType.valueOf(getTimingType()).getName();
    }

    /**
     * 获得控制台类型
     *
     * @return 控制台类型
     */
    public int getConsoleType() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return (headers[7] & 0x3);
    }

    /**
     * 获得控制台类型名称
     *
     * @return 控制台类型名称
     */
    public String getConsoleTypeName() {
        verifyFile();
        return ConsoleType.valueOf(getConsoleType()).getName();
    }


    /**
     * 获得 PPU类型
     *
     * @return PPU类型
     */
    public int getPpuType() {
        verifyFile();
        if (getConsoleType() != ConsoleType.CONSOLE_TYPE_1.getValue()) {
            return -1;
        }
        int[] headers = this.getRom().getHeaders();
        return (headers[13] & 0xf);
    }

    /**
     * 获得 PPU类型
     *
     * @return PPU类型名称
     */
    public String getPpuName() {
        verifyFile();
        if (getPpuType() == -1) {
            return "Unspecified ppu";
        }
        return PPUType.valueOf(getPpuType()).getName();
    }

    /**
     * 获得 PPU类型
     *
     * @return PPU类型
     */
    public int getHardwareType() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return ((headers[13] >> 4) & 0xf);
    }

    /**
     * 获得 PPU类型
     *
     * @return PPU类型名称
     */
    public String getHardwareName() {
        verifyFile();
        return HardwareType.valueOf(getHardwareType()).getName();
    }

    /**
     * 获得 扩展控制台类型
     *
     * @return 扩展控制台类型
     */
    public int getExtendedConsoleType() {
        verifyFile();
        if (getConsoleType() != ConsoleType.CONSOLE_TYPE_3.getValue()) {
            return -1;
        }
        int[] headers = this.getRom().getHeaders();
        return (headers[13] & 0xf);
    }

    /**
     * 获得 扩展控制台类型名称
     *
     * @return 扩展控制台类型名称
     */
    public String getExtendedConsoleTypeName() {
        verifyFile();
        if (getExtendedConsoleType() == -1) {
            return "Unspecified extended console";
        }
        return ExtendedConsoleType.valueOf(getExtendedConsoleType()).getName();
    }

    /**
     * 获得 扩展设备
     *
     * @return 扩展设备
     */
    public int getExpansionDevice() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return (headers[15] & 0x3f);
    }

    /**
     * 获得 扩展设备名称
     *
     * @return 扩展设备名称
     */
    public String getExpansionDeviceName() {
        verifyFile();
        return ExpansionDevice.valueOf(getExpansionDevice()).getName();
    }

    /**
     * 获得 其他rom数量
     *
     * @return 其他rom数量
     */
    public int getMiscellaneousRomCount() {
        verifyFile();
        int[] headers = this.getRom().getHeaders();
        return (headers[14] & 0x3);
    }

    public NesTvSystem getNesTvSystem() {
        switch (getTimingType()) {
            case 0x00:
                return NesTvSystem.valueOf(0);
            case 0x01:
                return NesTvSystem.valueOf(1);
            default:
                return NesTvSystem.valueOf(2);
        }
    }
}
