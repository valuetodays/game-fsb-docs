package com.omuao.rom.nes.common.model.memory.impl;

import com.omuao.rom.nes.common.exception.MemoryIOException;
import com.omuao.rom.nes.common.exception.MemoryIndexOutOfBoundsException;
import com.omuao.rom.nes.common.model.device.DeviceInfo;
import com.omuao.rom.nes.common.model.device.DeviceType;
import com.omuao.rom.nes.common.model.memory.Memory;

import java.util.ArrayList;
import java.util.List;

/**
 * 内存
 *
 * @author yumi@oumao.com
 * @since 2019-07-09
 **/
public class MemoryImpl implements Memory {

    /**
     * 内存
     */
    private int[] memory;

    /**
     * 只读
     */
    private boolean read;

    /**
     * 只写
     */
    private boolean write;

    /**
     * 数据总线
     */
    private int dataBus;

    /**
     * 数据位数
     */
    private int dataBit;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备编码
     */
    private String deviceCode;

    /**
     * 设备类型
     */
    private DeviceType deviceType;

    /**
     * 设备信息
     */
    private List<DeviceInfo> deviceContents;

    public MemoryImpl() {
        this.memory = new int[0xFF];
        initMemoryInfo();
    }

    public MemoryImpl(int size) {
        this.memory = new int[size];
        initMemoryInfo();
    }

    private void initMemoryInfo() {
        this.deviceName = "Memory"; //设备名称
        this.deviceCode = "Memory"; //设备编码
        this.deviceType = DeviceType.MEMORY; //设备类型
        this.deviceContents = new ArrayList<>();//设备信息
    }

    private void verifyAddressBounds(int address) {
        if (memory == null || address > memory.length || address < 0) {
            throw new MemoryIndexOutOfBoundsException(address);
        }
    }

    @Override
    public int read(int address) {
        verifyAddressBounds(address);
        if (!isRead()) {
            throw new MemoryIOException("内存不可读！");
        }
        return memory[address];
    }

    @Override
    public void write(int address, int data) {
        verifyAddressBounds(address);
        if (!isWrite()) {
            throw new MemoryIOException("内存不可写！");
        }
        memory[address] = data;
    }

    @Override
    public boolean readOnly() {
        return isRead() && (!isWrite());
    }

    @Override
    public boolean writeOnly() {
        return isWrite() && (!isRead());
    }

    @Override
    public void setDataBusBit(int dataBusBit) {
        this.setDataBit(dataBusBit);
    }

    @Override
    public int getDataBusBit() {
        return getDataBit();
    }

    @Override
    public int getIntDataBus() {
        return getDataBus();
    }

    @Override
    public void setWritable(boolean writable) {
        this.write = writable;
    }

    @Override
    public void setReadable(boolean readable) {
        this.read = readable;
    }

    public int[] getMemory() {
        return memory;
    }

    public void setMemory(int[] memory) {
        this.memory = memory;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public boolean isWrite() {
        return write;
    }

    public void setWrite(boolean write) {
        this.write = write;
    }

    public int getDataBus() {
        return dataBus;
    }

    public void setDataBus(int dataBus) {
        this.dataBus = dataBus & getBitFilter();
    }

    public int getDataBit() {
        return dataBit;
    }

    public void setDataBit(int dataBit) {
        if (dataBit > 24) {
            dataBit = 24;
        }
        dataBit = (dataBit / 4) * 4;
        this.dataBit = dataBit;
    }

    private int getBitFilter() {
        switch (getDataBit()) {
            case 4:
                return 0xf;
            case 8:
                return 0xff;
            case 12:
                return 0xfff;
            case 16:
                return 0xffff;
            case 20:
                return 0xfffff;
            case 24:
                return 0xffffff;
            default:
                return 0xffffff;
        }
    }

    @Override
    public String getDeviceName() {
        return deviceName;
    }

    @Override
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    @Override
    public String getDeviceCode() {
        return deviceCode;
    }

    @Override
    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    @Override
    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public List<DeviceInfo> getDeviceContents() {
        return deviceContents;
    }

    @Override
    public void setDeviceContents(List<DeviceInfo> deviceContents) {
        this.deviceContents = deviceContents;
    }
}
