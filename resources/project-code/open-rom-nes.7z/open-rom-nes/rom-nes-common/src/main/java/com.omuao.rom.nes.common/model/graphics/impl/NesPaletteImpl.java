package com.omuao.rom.nes.common.model.graphics.impl;

import com.omuao.rom.nes.common.model.graphics.Color;
import com.omuao.rom.nes.common.model.graphics.Palette;

/**
 * 调色板
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesPaletteImpl implements Palette {

    private Color[] colors;

    public NesPaletteImpl() {
    }

    public NesPaletteImpl(Color[] colors) {
        this.colors = colors;
    }

    @Override
    public void init(int size) {
        colors = new Color[size];
    }

    @Override
    public Color[] getColors() {
        return colors;
    }

    @Override
    public void setColors(Color[] colors) {
        this.colors = colors;
    }

    @Override
    public Color getColor(int index) {
        if (colors == null) {
            return null;
        }

        if (index < 0) {
            return null;
        }

        if (index > colors.length) {
            return null;
        }
        return colors[index];
    }

    @Override
    public void setColor(int index, int argb) {
        if (colors == null) {
            return;
        }

        if (index < 0) {
            return;
        }

        if (index > colors.length) {
            return;
        }

        colors[index] = new ColorImpl();
        colors[index].setArgb(argb);

    }
}
