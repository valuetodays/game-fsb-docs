package com.omuao.rom.nes.common.model.instruction.impl;

import com.omuao.rom.nes.common.model.instruction.InstructionInfo;

/**
 * 指令信息实现类
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public class InstructionInfoImpl implements InstructionInfo {

    /**
     * 机器码
     */
    private String machineCode;

    /**
     * 长度
     */
    private Integer length;

    /**
     * 时钟
     */
    private Integer clock;

    /**
     * 需要检查跨页
     */
    private boolean needCheckCrossPage;

    /**
     * 需要检查分支
     */
    private boolean needCheckBranch;

    /**
     * 寻址方式
     */
    private String addressMode;

    public InstructionInfoImpl() {
    }

    public InstructionInfoImpl(String machineCode, Integer length, Integer clock) {
        this.machineCode = machineCode;
        this.length = length;
        this.clock = clock;
    }

    public InstructionInfoImpl(String machineCode, Integer length, Integer clock, String addressMode) {
        this.machineCode = machineCode;
        this.length = length;
        this.clock = clock;
        this.addressMode = addressMode;
    }

    public InstructionInfoImpl(String machineCode, Integer length, Integer clock, boolean needCheckCrossPage, boolean needCheckBranch) {
        this.machineCode = machineCode;
        this.length = length;
        this.clock = clock;
        this.needCheckCrossPage = needCheckCrossPage;
        this.needCheckBranch = needCheckBranch;
    }

    public InstructionInfoImpl(String machineCode, Integer length, Integer clock, String addressMode, boolean needCheckCrossPage, boolean needCheckBranch) {
        this.machineCode = machineCode;
        this.length = length;
        this.clock = clock;
        this.needCheckCrossPage = needCheckCrossPage;
        this.needCheckBranch = needCheckBranch;
        this.addressMode = addressMode;
    }

    @Override
    public String getMachineCode() {
        return machineCode;
    }

    @Override
    public void setMachineCode(String machineCode) {
        this.machineCode = machineCode;
    }

    @Override
    public Integer getLength() {
        return length;
    }

    @Override
    public void setLength(Integer length) {
        this.length = length;
    }

    @Override
    public Integer getClock() {
        return clock;
    }

    @Override
    public void setClock(Integer clock) {
        this.clock = clock;
    }

    @Override
    public boolean isNeedCheckCrossPage() {
        return needCheckCrossPage;
    }

    @Override
    public void setNeedCheckCrossPage(boolean needCheckCrossPage) {
        this.needCheckCrossPage = needCheckCrossPage;
    }

    @Override
    public boolean isNeedCheckBranch() {
        return needCheckBranch;
    }

    @Override
    public void setNeedCheckBranch(boolean needCheckBranch) {
        this.needCheckBranch = needCheckBranch;
    }

    @Override
    public String getAddressMode() {
        return addressMode;
    }

    @Override
    public void setAddressMode(String addressMode) {
        this.addressMode = addressMode;
    }

}
