package com.omuao.rom.nes.common.enums;

/**
 * 扩展设备
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum ExpansionDevice {
    EXPANSION_DEVICE_OO(0x00, "Unspecified"),
    EXPANSION_DEVICE_O1(0x01, "Standard NES/Famicom controllers"),
    EXPANSION_DEVICE_O2(0x02, "NES Four Score/Satellite with two additional standard controllers"),
    EXPANSION_DEVICE_O3(0x03, "Famicom Four Players Adapter with two additional standard controllers"),
    EXPANSION_DEVICE_O4(0x04, "Vs. System"),
    EXPANSION_DEVICE_O5(0x05, "Vs. System with reversed inputs"),
    EXPANSION_DEVICE_O6(0x06, "Vs. Pinball (Japan)"),
    EXPANSION_DEVICE_O7(0x07, "Vs. Zapper"),
    EXPANSION_DEVICE_O8(0x08, "Zapper ($4017)"),
    EXPANSION_DEVICE_O9(0x09, "Two Zappers"),
    EXPANSION_DEVICE_OA(0x0A, "Bandai Hyper Shot"),
    EXPANSION_DEVICE_OB(0x0B, "Power Pad Side A"),
    EXPANSION_DEVICE_OC(0x0C, "Power Pad Side B"),
    EXPANSION_DEVICE_OD(0x0D, "Family Trainer Side A"),
    EXPANSION_DEVICE_OE(0x0E, "Family Trainer Side B"),
    EXPANSION_DEVICE_OF(0x0F, "Arkanoid Vaus Controller (NES)"),
    EXPANSION_DEVICE_10(0x10, "Arkanoid Vaus Controller (Famicom)"),
    EXPANSION_DEVICE_11(0x11, "Two Vaus Controllers plus Famicom Data Recorder"),
    EXPANSION_DEVICE_12(0x12, "Konami Hyper Shot"),
    EXPANSION_DEVICE_13(0x13, "Coconuts Pachinko Controller"),
    EXPANSION_DEVICE_14(0x14, "Exciting Boxing Punching Bag"),
    EXPANSION_DEVICE_15(0x15, "Jissen Mahjong Controller"),
    EXPANSION_DEVICE_16(0x16, "Party Tap"),
    EXPANSION_DEVICE_17(0x17, "Oeka Kids Tablet"),
    EXPANSION_DEVICE_18(0x18, "Sunsoft Barcode Battler"),
    EXPANSION_DEVICE_19(0x19, "Miracle Piano Keyboard"),
    EXPANSION_DEVICE_1A(0x1A, "Pokkun Moguraa"),
    EXPANSION_DEVICE_1B(0x1B, "Top Rider"),
    EXPANSION_DEVICE_1C(0x1C, "Double-Fisted"),
    EXPANSION_DEVICE_1D(0x1D, "Famicom 3D System"),
    EXPANSION_DEVICE_1E(0x1E, "Doremikko Keyboard"),
    EXPANSION_DEVICE_1F(0x1F, "R.O.B. Gyro Set"),
    EXPANSION_DEVICE_20(0x20, "Famicom Data Recorder (don't emulate keyboard)"),
    EXPANSION_DEVICE_21(0x21, "ASCII Turbo File"),
    EXPANSION_DEVICE_22(0x22, "IGS Storage Battle Box"),
    EXPANSION_DEVICE_23(0x23, "Family BASIC Keyboard plus Famicom Data Recorder"),
    EXPANSION_DEVICE_24(0x24, "Dongda PEC-586 Keyboard"),
    EXPANSION_DEVICE_25(0x25, "Bit Corp. Bit-79 Keyboard"),
    EXPANSION_DEVICE_26(0x26, "Subor Keyboard"),
    EXPANSION_DEVICE_27(0x27, "Subor Keyboard plus mouse (3x8-bit protocol)"),
    EXPANSION_DEVICE_28(0x28, "Subor Keyboard plus mouse (24-bit protocol)"),
    EXPANSION_DEVICE_29(0x29, "SNES Mouse ($4017.d0)"),
    EXPANSION_DEVICE_2A(0x2A, "Multicart"),
    EXPANSION_DEVICE_2B(0x2B, "Two SNES controllers replacing the two standard NES controllers"),
    EXPANSION_DEVICE_2C(0x2C, "RacerMate Bicycle"),
    EXPANSION_DEVICE_2D(0x2D, "U-Force"),
    EXPANSION_DEVICE_2E(0x2E, "R.O.B. Stack-Up");

    /**
     * 扩展设备值
     */
    private int value;

    /**
     * 扩展设备名称
     */
    private String name;

    ExpansionDevice(int value, String name) {

        this.value = value;

        this.name = name;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public static ExpansionDevice valueOf(int type) {
        for (ExpansionDevice consoleType : ExpansionDevice.values()) {
            if (consoleType.getValue() == type) {
                return consoleType;
            }
        }
        return null;
    }
}
