package com.omuao.rom.nes.common.io;

import com.omuao.rom.nes.common.enums.NesTvSystem;
import com.omuao.rom.nes.common.exception.NesFileException;
import com.omuao.rom.nes.common.exception.UnSupportFileError;
import com.omuao.rom.nes.common.rom.NesFileRom;
import com.omuao.rom.nes.common.enums.MMCLibrary;
import com.omuao.rom.nes.common.enums.NesRomCode;
import com.omuao.rom.nes.common.rom.impl.NesFileRomImpl;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URI;
import java.util.ArrayList;
import java.util.List;

/**
 * NES 文件
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFile extends File {

    /**
     * 镜像
     */
    private NesFileRom rom;

    /**
     * 读取
     */
    private int offset;

    public NesFile(String pathname) {
        super(pathname);
        init();
    }

    public NesFile(String parent, String child) {
        super(parent, child);
        init();
    }

    public NesFile(File parent, String child) {
        super(parent, child);
        init();
    }

    public NesFile(URI uri) {
        super(uri);
        init();
    }

    void init() {
        if (!this.exists()) {
            return;
        }
        if (!this.isFile()) {
            return;
        }
        if (!this.canRead()) {
            return;
        }

        NesFileRomImpl rom = new NesFileRomImpl();

        FileInputStream in = null;

        try {
            in = new FileInputStream(this);

            in.mark(0);

            int[] headers = new int[16];

            for (int i = 0; i < headers.length; i++) {
                headers[i] = in.read();
            }

            rom.setHeaders(headers);

            //所有的配置
            List<Integer> allConfigs = new ArrayList<>();

            // NES标识
            if ('N' == headers[0] && 'E' == headers[1] && 'S' == headers[2] && headers[3] == 0x1A) {

                // 程序数据块数
                int prgRomsCount = headers[4];
                allConfigs.add(prgRomsCount);
                rom.setProgramRomCount(prgRomsCount);

                // 图案数据块数
                int chrRomsCount = headers[5];
                allConfigs.add(chrRomsCount);
                rom.setGraphicsRomCount(chrRomsCount);

                int d6Tag = headers[6];
                allConfigs.add(d6Tag);
                rom.setScreenConfig(d6Tag);

                int d7Tag = headers[7];
                allConfigs.add(d7Tag);
                rom.setMemoryConfig(d7Tag);

                int d8Tag = headers[8];
                allConfigs.add(d8Tag);

                int d9Tag = headers[9];
                allConfigs.add(d9Tag);
                rom.setTvConfig(d9Tag);

                int d10Tag = headers[10];
                allConfigs.add(d10Tag);
                rom.setOtherConfig(d10Tag);

            } else {
                throw new UnSupportFileError("不支持的文件！");
            }

            int[] allConfig = new int[allConfigs.size()];

            for (int i = 0; i < allConfigs.size(); i++) {
                allConfig[i] = allConfigs.get(i).intValue();
            }

            rom.setAllConfigs(allConfig);

        } catch (Exception e) {
            throw new NesFileException(e);
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                throw new NesFileException(e);
            }
        }
        this.rom = rom;
    }

    /**
     * 载入ROM
     */
    public long loadRom() {

        long index = 0;
        FileInputStream in = null;
        try {

            in = new FileInputStream(this);

            in.mark(0);

            in.skip(0x10L);

            index += 0x10L;

            if (this.isHaveTrainer()) {

                //金手指数据区
                int[] trainerData = new int[0x200];

                for (int i = 0; i < trainerData.length; i++) {
                    trainerData[i] = in.read();
                }

                if (rom instanceof NesFileRomImpl) {
                    ((NesFileRomImpl) rom).setTrainerData(trainerData);
                }

                index += 0x200;
            }

            // 程序ROM 0x4000 = 16KB = 16384byte 。( 1KB = 1024byte );
            int romBank[][] = new int[rom.getProgramRomCount()][0x4000];
            for (int romCount = 0; romCount < romBank.length; romCount++) {
                for (int data = 0; data < 0x4000; data++) {
                    romBank[romCount][data] = in.read();
                }
                index += 0x4000;
            }

            if (rom instanceof NesFileRomImpl) {
                ((NesFileRomImpl) rom).setProgramRoms(romBank);
            }

            // 图形ROM 0x2000 = 8KB = 8192byte 。( 1KB = 1024byte );
            int graphicsBank[][] = new int[rom.getGraphicsRomCount()][0x2000];
            for (int romCount = 0; romCount < graphicsBank.length; romCount++) {
                for (int data = 0; data < 0x2000; data++) {
                    graphicsBank[romCount][data] = in.read();
                }
                index += 0x2000;
            }

            if (rom instanceof NesFileRomImpl) {
                ((NesFileRomImpl) rom).setGraphicsRoms(graphicsBank);
            }
        } catch (Exception e) {
            throw new NesFileException(e);
        } finally {
            try {
                in.close();
            } catch (IOException e) {
                throw new NesFileException(e);
            }
        }

        return index;
    }

    protected void verifyFile() {
        if (rom == null) {
            throw new NesFileException("镜像未正确加载！");
        }
    }

    /**
     * 是否是NES镜像
     *
     * @return
     */
    public boolean isNesRom() {
        verifyFile();
        int[] headers = this.rom.getHeaders();

        if (headers == null) {
            return false;
        }

        if ('N' == headers[0] && 'E' == headers[1] && 'S' == headers[2] && headers[3] == 0x1A) {
            return true;
        }
        return false;
    }

    /**
     * 是否为NES2.0 镜像
     *
     * @return
     */
    public boolean isNes2Rom() {
        verifyFile();
        int[] headers = this.rom.getHeaders();

        if (headers == null) {
            return false;
        }

        if (isNesRom() && (headers[7] & 0x0C) == 0x08) {
            return true;
        }
        return false;
    }

    /**
     * 是否是垂直镜像
     *
     * @return
     */
    public boolean isVerticalImage() {
        verifyFile();
        return (this.rom.getScreenConfig() & 1) == NesRomCode.VERTICAL_IMAGE.getValue();
    }

    /**
     * 是否是水平镜像
     *
     * @return
     */
    public boolean isHorizontalImage() {
        verifyFile();
        return (this.rom.getScreenConfig() & 1) == NesRomCode.HORIZONTAL_IMAGE.getValue();
    }

    /**
     * 是否含有电池记忆
     *
     * @return
     */
    public boolean isHaveBatterMemory() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 1 & 1) == NesRomCode.HAVE_BATTER_MEMORY.getValue();
    }

    /**
     * 是否不含有电池记忆
     *
     * @return
     */
    public boolean isNoHaveBatterMemory() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 1 & 1) == NesRomCode.UN_HAVE_BATTER_MEMORY.getValue();
    }

    /**
     * 是否含有Trainer（金手指）
     *
     * @return
     */
    public boolean isHaveTrainer() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 2 & 1) == NesRomCode.HAVE_TRAINER.getValue();
    }

    /**
     * 是否不含有Trainer（金手指）
     *
     * @return
     */
    public boolean isUnHaveTrainer() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 2 & 1) == NesRomCode.UN_HAVE_TRAINER.getValue();
    }

    /**
     * 是否是四块屏幕
     *
     * @return
     */
    public boolean isFourScreen() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 3 & 1) == NesRomCode.FOUR_SCREEN.getValue();
    }

    /**
     * 是否是其他屏幕
     *
     * @return
     */
    public boolean isOtherScreen() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 3 & 1) == NesRomCode.OTHER_SCREEN.getValue();
    }

    /**
     * 获得MapperType 映射MMC类型
     *
     * @return
     */
    public int getMapperType() {
        verifyFile();
        return (this.rom.getScreenConfig() >> 4) | (this.rom.getMemoryConfig() & 0xf0);
    }

    public String getMapperTypeName() {
        verifyFile();
        String name = MMCLibrary.MAPPER_NAME_LIB.get(getMapperType());
        return name == null ? "Misc(Unknown)" : name;
    }

    /**
     * 获得系统制式
     *
     * @return
     */
    public int getTVSystem() {
        verifyFile();
        return (this.rom.getTvConfig() & 1);
    }

    /**
     * NTSC制式
     *
     * @return
     */
    public boolean isNTSC() {
        verifyFile();
        return getTVSystem() == NesRomCode.TV_NTSC.getValue();
    }

    /**
     * PAL制式
     *
     * @return
     */
    public boolean isPAL() {
        verifyFile();
        return getTVSystem() == NesRomCode.TV_PAL.getValue();
    }

    /**
     * 获得兼容的制式
     *
     * @return
     */
    public int getCompatible() {
        verifyFile();
        return (rom.getOtherConfig() & 3);
    }

    /**
     * 是否兼容NTSC
     *
     * @return
     */
    public boolean isCompatibleNTSC() {
        verifyFile();
        return getCompatible() == NesRomCode.COMPATIBLE_NTSC.getValue() || ((getCompatible() % 2) != 0);
    }

    /**
     * 是否兼容PAL
     *
     * @return
     */
    public boolean isCompatiblePAL() {
        verifyFile();
        return getCompatible() == NesRomCode.COMPATIBLE_PAL.getValue() || ((getCompatible() % 2) != 0);
    }

    /**
     * 存在PRG RAM
     *
     * @return
     */
    public boolean isExistProgramRam() {
        verifyFile();
        return ((this.rom.getOtherConfig() >> 4) & 1) == NesRomCode.EXIST_PROGRAM_RAM.getValue();
    }

    /**
     * 不存在RPG RAM
     *
     * @return
     */
    public boolean isUnExistProgramRam() {
        verifyFile();
        return ((this.rom.getOtherConfig() >> 4) & 1) == NesRomCode.UN_EXIST_PROGRAM_RAM.getValue();
    }

    /**
     * 有总线冲突
     *
     * @return
     */
    public boolean isHaveBusConflicts() {
        verifyFile();
        return ((this.rom.getOtherConfig() >> 5) & 1) == NesRomCode.EXIST_BUS_CONFLICTS.getValue();
    }

    /**
     * 没有总线冲突
     *
     * @return
     */
    public boolean isNotHaveBusConflicts() {
        verifyFile();
        return ((this.rom.getOtherConfig() >> 5) & 1) == NesRomCode.UN_EXIST_BUS_CONFLICTS.getValue();
    }

    public NesTvSystem getNesTvSystem() {
        if (isNTSC()) {
            return NesTvSystem.valueOf(0);
        } else if (isPAL()) {
            return NesTvSystem.valueOf(1);
        } else {
            if (isCompatibleNTSC() && isCompatiblePAL()) {
                return NesTvSystem.valueOf(2);
            } else if (isCompatibleNTSC() && !isCompatiblePAL()) {
                return NesTvSystem.valueOf(0);
            } else {
                return NesTvSystem.valueOf(1);
            }
        }
    }

    public NesFileRom getRom() {
        return rom;
    }

    public void setRom(NesFileRom rom) {
        this.rom = rom;
    }
}
