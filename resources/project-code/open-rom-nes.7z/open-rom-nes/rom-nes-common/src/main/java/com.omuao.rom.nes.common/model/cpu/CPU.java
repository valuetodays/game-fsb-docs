package com.omuao.rom.nes.common.model.cpu;

import com.omuao.rom.nes.common.model.address.AddressMode;
import com.omuao.rom.nes.common.model.device.Device;
import com.omuao.rom.nes.common.model.device.DeviceInfo;
import com.omuao.rom.nes.common.model.instruction.InstructionSet;
import com.omuao.rom.nes.common.model.memory.Memory;
import com.omuao.rom.nes.common.model.register.Register;

import java.util.List;
import java.util.Map;

/**
 * CPU接口
 *
 * @author yumi@oumao.com
 * @since 2019-07-10
 **/
public interface CPU extends Device {

    /**
     * 获得指令集
     *
     * @return 指令集
     */
    List<InstructionSet> getInstructionSet();

    /**
     * 设置指令集
     *
     * @param instructionSet 指令集
     */
    void setInstructionSet(List<InstructionSet> instructionSet);

    /**
     * 获得内存
     *
     * @return 内存
     */
    Memory getMemory();

    /**
     * 设置内存
     *
     * @param memory 内存
     */
    void setMemory(Memory memory);

    /**
     * 模拟CPU 操作
     *
     * @return 下一次程序指针，或者程序下次计数器的值
     */
    int emulate();

    /**
     * 获得寄存器
     *
     * @return
     */
    List<Register> getRegisters();

    /**
     * 设置寄存器
     *
     * @param registers 寄存器
     */
    void setRegisters(List<Register> registers);

    /**
     * 获得寻址方式
     *
     * @return
     */
    Map<String, AddressMode> getAddressModeMap();

    /**
     * 设置寻址方式
     *
     * @param addressModeMap 寻址方式map
     */
    void setAddressModeMap(Map<String, AddressMode> addressModeMap);

    /**
     * 设备Map
     *
     * @return
     */
    Map<String, Device> getDeviceMap();

    /**
     * 设置设备
     *
     * @param deviceMap 设备信息
     */
    void setDeviceMap(Map<String, Device> deviceMap);
}
