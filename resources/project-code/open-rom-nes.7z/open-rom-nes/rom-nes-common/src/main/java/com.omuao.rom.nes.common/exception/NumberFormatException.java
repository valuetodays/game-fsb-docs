package com.omuao.rom.nes.common.exception;

/**
 * 数字格式异常
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class NumberFormatException extends Exception {

    public NumberFormatException() {
    }

    public NumberFormatException(String message) {
        super(message);
    }

    public NumberFormatException(String message, Throwable cause) {
        super(message, cause);
    }

    public NumberFormatException(Throwable cause) {
        super(cause);
    }

}