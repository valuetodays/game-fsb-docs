package com.omuao.rom.nes.common.enums;

/**
 * 时序类型
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public enum TimingType {

    TIMING_TYPE_00(0x00, "RP2C02", "North America, Japan, South Korea, Taiwan"),
    TIMING_TYPE_01(0x01, "RP2C07", "Western Europe, Australia"),
    TIMING_TYPE_02(0x02, "UNKNOWN", "UNKNOWN"),
    TIMING_TYPE_03(0x03, "UMC 6527P", "Eastern Europe, Russia, Mainland China, India, Africa");

    /**
     * 时序类型值
     */
    private int value;

    /**
     * 时序名称
     */
    private String name;

    /**
     * 区域
     */
    private String regions;

    TimingType(int value, String name, String regions) {
        this.value = value;
        this.name = name;
        this.regions = regions;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRegions() {
        return regions;
    }

    public void setRegions(String regions) {
        this.regions = regions;
    }

    public static TimingType valueOf(int type) {
        for (TimingType timingType : TimingType.values()) {
            if (timingType.getValue() == type) {
                return timingType;
            }
        }
        return null;
    }
}
