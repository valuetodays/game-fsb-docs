package com.omuao.rom.nes.common.enums;

/**
 * 镜像代码
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public enum NesRomCode {

    /**
     * 垂直镜像
     */
    VERTICAL_IMAGE(1),
    /**
     * 水平镜像
     */
    HORIZONTAL_IMAGE(0),
    /**
     * 含有电池记忆
     */
    HAVE_BATTER_MEMORY(1),

    /**
     * 不含有电池记忆
     */
    UN_HAVE_BATTER_MEMORY(0),

    /**
     * 含有金手指
     */
    HAVE_TRAINER(1),

    /**
     * 不含有金手指
     */
    UN_HAVE_TRAINER(0),

    /**
     * 四块屏
     */
    FOUR_SCREEN(1),

    /**
     * 其他屏
     */
    OTHER_SCREEN(0),

    /**
     * PAL制式
     */
    TV_PAL(0),

    /**
     * NTSC制式
     */
    TV_NTSC(1),

    /**
     * 存在程序RAM($ 6000- $ 7FFF)
     */
    EXIST_PROGRAM_RAM(0),

    /**
     * 不存在程序RAM
     */
    UN_EXIST_PROGRAM_RAM(1),

    /**
     * 存在总线冲突
     */
    EXIST_BUS_CONFLICTS(1),

    /**
     * 不存在总线冲突
     */
    UN_EXIST_BUS_CONFLICTS(0),

    /**
     * 兼容NTSC
     */
    COMPATIBLE_NTSC(0),

    /**
     * 兼容PAL
     */
    COMPATIBLE_PAL(2);

    NesRomCode(int i) {
        this.value = i;
    }

    private int value;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
}
