package com.omuao.rom.nes.common.rom;

/**
 * NES2.0 文件镜像
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public interface NesFile2Rom extends NesFileRom {

    int getMiscellaneousRomCount();

    int[][] getMiscellaneousRoms();
}
