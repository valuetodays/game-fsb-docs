package com.omuao.rom.nes.common.model.address;

/**
 * 寻址方式
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public interface AddressMode<IN, OUT> {

    /**
     * 寻址方式的编码
     *
     * @return 编码
     */
    String getCode();

    /**
     * 设置寻址方式的编码
     *
     * @param code 编码
     */
    void setCode(String code);


    /**
     * 寻址方式的名称
     *
     * @return 名称
     */
    String getName();

    /**
     * 设置寻址方式的名称
     *
     * @param name 名称
     */
    void setName(String name);

    /**
     * 寻址
     *
     * @param in 输入
     * @return 输出数据
     */
    OUT addressing(IN in);
}
