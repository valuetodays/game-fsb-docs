package com.omuao.rom.nes.common.exception;

/**
 * 不支持的文件
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class UnSupportFileError extends RuntimeException {

    public UnSupportFileError() {
    }

    public UnSupportFileError(String message) {
        super(message);
    }

    public UnSupportFileError(String message, Throwable cause) {
        super(message, cause);
    }

    public UnSupportFileError(Throwable cause) {
        super(cause);
    }
}
