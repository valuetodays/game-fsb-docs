package com.omuao.rom.nes.common.rom.impl;

import com.omuao.rom.nes.common.model.device.DeviceInfo;
import com.omuao.rom.nes.common.model.device.DeviceType;
import com.omuao.rom.nes.common.rom.NesFileRom;

import java.util.ArrayList;
import java.util.List;

/**
 * NES 文件镜像实现类
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class NesFileRomImpl implements NesFileRom {

    /**
     * 文件标识
     */
    private int[] fileTag;

    /**
     * 程序镜像 数量
     */
    private int programRomCount;

    /**
     * 图形镜像 数量(0 表示CHR RAM)
     */
    private int graphicsRomCount;

    /**
     * 屏幕相关配置参数
     */
    private int screenConfig;

    /**
     * 内存镜像相关配置参数
     */
    private int memoryConfig;

    /**
     * 电视相关配置参数
     */
    private int tvConfig;

    /**
     * 其他配置参数
     */
    private int otherConfig;

    /**
     * 所有的参数
     */
    private int[] allConfigs;

    /**
     * 图形镜像
     */
    private int[][] graphicsRoms;

    /**
     * 程序镜像
     */
    private int[][] programRoms;

    /**
     * 金手指数据区
     */
    private int[] trainerData;

    /**
     * 头部数据
     */
    private int[] headers;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备编码
     */
    private String deviceCode;

    /**
     * 设备类型
     */
    private DeviceType deviceType;

    /**
     * 设备信息
     */
    private List<DeviceInfo> deviceContents;

    public NesFileRomImpl() {
        this.deviceName = "NES 1.0 ROM"; //设备名称
        this.deviceCode = "NES 1.0 ROM"; //设备编码
        this.deviceType = DeviceType.MEMORY; //设备类型
        this.deviceContents = new ArrayList<>();//设备信息
    }

    @Override
    public int[] getFileTag() {
        return fileTag;
    }

    public void setFileTag(int[] fileTag) {
        this.fileTag = fileTag;
    }

    @Override
    public int getProgramRomCount() {
        return programRomCount;
    }

    public void setProgramRomCount(int programRomCount) {
        this.programRomCount = programRomCount;
    }

    @Override
    public int getGraphicsRomCount() {
        return graphicsRomCount;
    }

    public void setGraphicsRomCount(int graphicsRomCount) {
        this.graphicsRomCount = graphicsRomCount;
    }

    @Override
    public int getScreenConfig() {
        return screenConfig;
    }

    public void setScreenConfig(int screenConfig) {
        this.screenConfig = screenConfig;
    }

    @Override
    public int getMemoryConfig() {
        return memoryConfig;
    }

    public void setMemoryConfig(int memoryConfig) {
        this.memoryConfig = memoryConfig;
    }

    @Override
    public int getTvConfig() {
        return tvConfig;
    }

    public void setTvConfig(int tvConfig) {
        this.tvConfig = tvConfig;
    }

    @Override
    public int getOtherConfig() {
        return otherConfig;
    }

    public void setOtherConfig(int otherConfig) {
        this.otherConfig = otherConfig;
    }

    @Override
    public int[] getAllConfigs() {
        return allConfigs;
    }

    public void setAllConfigs(int[] allConfigs) {
        this.allConfigs = allConfigs;
    }

    @Override
    public int[][] getGraphicsRoms() {
        return graphicsRoms;
    }

    public void setGraphicsRoms(int[][] graphicsRoms) {
        this.graphicsRoms = graphicsRoms;
    }

    @Override
    public int[][] getProgramRoms() {
        return programRoms;
    }

    public void setProgramRoms(int[][] programRoms) {
        this.programRoms = programRoms;
    }

    @Override
    public int[] getTrainerData() {
        return trainerData;
    }

    public void setTrainerData(int[] trainerData) {
        this.trainerData = trainerData;
    }

    public int[] getHeaders() {
        return headers;
    }

    public void setHeaders(int[] headers) {
        this.headers = headers;
    }

    @Override
    public String getDeviceName() {
        return deviceName;
    }

    @Override
    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    @Override
    public String getDeviceCode() {
        return deviceCode;
    }

    @Override
    public void setDeviceCode(String deviceCode) {
        this.deviceCode = deviceCode;
    }

    @Override
    public DeviceType getDeviceType() {
        return deviceType;
    }

    @Override
    public void setDeviceType(DeviceType deviceType) {
        this.deviceType = deviceType;
    }

    @Override
    public List<DeviceInfo> getDeviceContents() {
        return deviceContents;
    }

    @Override
    public void setDeviceContents(List<DeviceInfo> deviceContents) {
        this.deviceContents = deviceContents;
    }
}
