package com.omuao.rom.nes.common.model.graphics.impl;

import com.omuao.rom.nes.common.model.graphics.GraphicsTable;
import com.omuao.rom.nes.common.model.graphics.Grid;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

/**
 * 绘制表
 *
 * @author yumi@oumao.com
 * @since 2019-07-08
 **/
public class GraphicsTableImpl implements GraphicsTable {

    /**
     * 数据
     */
    private int[][] data;

    /**
     * 格子
     */
    private Grid[] grids;

    @Override
    public Grid[] getGrids() {
        return grids;
    }

    public void setGrids(GridImpl[] grids) {
        if (grids != null) {
            data = new int[grids.length][];
            for (int i = 0; i < grids.length; i++) {
                data[i] = grids[i].getData();
            }
        }
        this.grids = grids;
    }

    @Override
    public BufferedImage getRenderingImage() {
        return getRenderingImage(16, false, false);
    }

    @Override
    public BufferedImage getRenderingImage(boolean reversal) {
        return getRenderingImage(16, reversal, false);
    }

    @Override
    public BufferedImage getRenderingImage(int grids, boolean reversal, boolean vertical) {
        if (vertical) {
            return renderingVerticalImage(grids, reversal);
        }
        return renderingHorizontalImage(grids, reversal);
    }

    @Override
    public BufferedImage getRenderingImage(int grids) {
        return getRenderingImage(grids, false, false);
    }

    @Override
    public BufferedImage getRenderingImage(boolean reversal, boolean vertical) {
        return getRenderingImage(16, reversal, vertical);
    }

    /**
     * 绘制水平图形
     *
     * @param grids 格子数
     * @return
     */
    private BufferedImage renderingHorizontalImage(int grids, boolean reversal) {

        int width = grids * 8;

        int height = this.grids.length / grids;

        if (this.grids.length % grids != 0) {
            ++height;
        }
        height *= 8;

        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);

        Graphics graphics = bufferedImage.getGraphics();
        int row = 0;
        int col = 0;
        for (int i = 0; i < this.grids.length; i++) {
            if (i % grids == 0 && i != 0) {
                ++row;
                col = 0;
            }
            int x = col * 8;
            int y = row * 8;
            Image image = this.getGrids()[i].getRenderingImage(reversal);
            graphics.drawImage(image, x, y, null);
            ++col;
        }
        return bufferedImage;
    }

    /**
     * 绘制垂直图形
     *
     * @param grids 格子数
     * @return
     */
    private BufferedImage renderingVerticalImage(int grids, boolean reversal) {

        int width = this.grids.length / grids;

        if (this.grids.length % grids != 0) {
            ++width;
        }

        width *= 8;

        int height = grids * 8;

        BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_4BYTE_ABGR);

        Graphics graphics = bufferedImage.getGraphics();
        int row = 0;
        int col = 0;
        for (int i = 0; i < this.grids.length; i++) {
            if (i % grids == 0 && i != 0) {
                ++col;
                row = 0;
            }
            int x = col * 8;
            int y = row * 8;
            Image image = this.getGrids()[i].getRenderingImage(reversal);
            graphics.drawImage(image, x, y, null);
            ++row;
        }
        return bufferedImage;
    }

    public int[][] getData() {
        return data;
    }

    public void setData(int[][] data) {
        if (data != null) {
            grids = new Grid[data.length];
            for (int i = 0; i < data.length; i++) {
                GridImpl grid = new GridImpl();
                grid.setData(data[i]);
                grids[i] = grid;
            }
        }
        this.data = data;
    }

    @Override
    public void valueOfGraphicsRom(int[] graphicsRom) {

        java.util.List<Grid> gridList = new ArrayList<Grid>();

        for (int i = 0; i < graphicsRom.length; i += 0x10) {

            int[] data = new int[16];
            System.arraycopy(graphicsRom, i, data, 0, 16);
            GridImpl grid = new GridImpl();
            grid.setData(data);
            gridList.add(grid);
        }

        GridImpl[] grids = gridList.toArray(new GridImpl[]{});

        setGrids(grids);
    }
}
