package com.omuao.rom.nes.common.model.instruction;

/**
 * 指令信息
 *
 * @author yumi@oumao.com
 * @since 2019-09-24
 **/
public interface InstructionInfo {

    /**
     * 机器码
     *
     * @return
     */
    String getMachineCode();

    /**
     * 设置机器码
     *
     * @param machineCode
     */
    void setMachineCode(String machineCode);

    /**
     * 指令长度
     *
     * @return
     */
    Integer getLength();

    /**
     * 设置指令长度
     *
     * @param length 长度
     */
    void setLength(Integer length);

    /**
     * 获得指令执行周期
     *
     * @return
     */
    Integer getClock();

    /**
     * 获得指令执行周期
     *
     * @return
     */
    void setClock(Integer clock);

    /**
     * 需要检查是否跨页，如果跨页+1
     *
     * @return
     */
    boolean isNeedCheckCrossPage();

    /**
     * 设置检查
     *
     * @param needCheckCrossPage
     */
    void setNeedCheckCrossPage(boolean needCheckCrossPage);

    /**
     * 检查分支是否在同页，在同页则时钟+1，不同页+2
     *
     * @return
     */
    boolean isNeedCheckBranch();

    /**
     * 设置检查
     *
     * @param needCheckBranch
     */
    void setNeedCheckBranch(boolean needCheckBranch);

    /**
     * 获得寻址方式
     *
     * @return
     */
    String getAddressMode();

    /**
     * 设置寻址方式
     *
     * @param addressMode 寻址方式
     */
    void setAddressMode(String addressMode);
}