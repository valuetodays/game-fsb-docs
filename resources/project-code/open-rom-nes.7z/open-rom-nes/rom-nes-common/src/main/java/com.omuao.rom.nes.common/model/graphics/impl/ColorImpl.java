package com.omuao.rom.nes.common.model.graphics.impl;

import com.omuao.rom.nes.common.model.graphics.Color;

/**
 * 颜色
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public class ColorImpl implements Color {

    /**
     * 红
     */
    private int r;

    /**
     * 绿
     */
    private int g;

    /**
     * 蓝
     */
    private int b;

    /**
     * 透明度
     */
    private int alpha;

    public ColorImpl() {
    }

    public ColorImpl(int r, int g, int b, int alpha) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.alpha = alpha;
    }

    @Override
    public int getR() {
        return r;
    }

    @Override
    public void setR(int r) {
        this.r = r;
    }

    @Override
    public int getG() {
        return g;
    }

    @Override
    public void setG(int g) {
        this.g = g & 0xff;
    }

    @Override
    public int getB() {
        return b;
    }

    @Override
    public void setB(int b) {
        this.b = b & 0xff;
    }

    @Override
    public int getAlpha() {
        return alpha;
    }

    @Override
    public void setAlpha(int alpha) {
        this.alpha = alpha & 0xff;
    }

    public int getArgb() {
        return (alpha << 24) | (r << 16) | (g << 8) | b;
    }

    public void setArgb(int argb) {
        alpha = (argb >> 24) & 0xff;
        r = (argb >> 16) & 0xff;
        g = (argb >> 8) & 0xff;
        b = argb & 0xff;
    }
}
