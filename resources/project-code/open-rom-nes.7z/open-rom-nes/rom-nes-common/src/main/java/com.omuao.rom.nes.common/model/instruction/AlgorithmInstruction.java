package com.omuao.rom.nes.common.model.instruction;

import com.omuao.rom.nes.common.model.converter.Converter;

/**
 * 算法指令
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface AlgorithmInstruction<R> extends Instruction {

    /**
     * 获得运算数据
     *
     * @return
     */
    R getOperationalData();

    /**
     * 计算数据
     */
    void calculate();

    /**
     * 获得转换器
     *
     * @return 转换器
     */
    Converter getConverter();

    /**
     * 设置转换器
     *
     * @param converter 转换器
     */
    void setConverter(Converter converter);

}