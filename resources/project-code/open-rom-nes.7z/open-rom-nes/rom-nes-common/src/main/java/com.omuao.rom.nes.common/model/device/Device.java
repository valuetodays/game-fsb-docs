package com.omuao.rom.nes.common.model.device;

import java.util.List;

/**
 * 设备
 *
 * @author yumi@oumao.com
 * @since 2019-09-25
 **/
public interface Device {

    /**
     * 获取设备名称
     *
     * @return 设备名称
     */
    String getDeviceName();

    /**
     * 设置名称
     *
     * @param name 名称
     */
    void setDeviceName(String name);

    /**
     * 获取设备编码
     *
     * @return 设备编码
     */
    String getDeviceCode();

    /**
     * 设置编码
     *
     * @param code 编码
     */
    void setDeviceCode(String code);

    /**
     * 获取设备类型
     *
     * @return 设备类型
     */
    DeviceType getDeviceType();

    /**
     * 设置类型
     *
     * @param deviceType 类型
     */
    void setDeviceType(DeviceType deviceType);

    /**
     * 获得设备信息
     *
     * @return 设备信息
     */
    List<DeviceInfo> getDeviceContents();

    /**
     * 设置设备信息
     *
     * @param deviceContents 设备信息
     */
    void setDeviceContents(List<DeviceInfo> deviceContents);

}