package com.omuao.rom.nes.common.enums;

import com.omuao.rom.nes.common.model.graphics.Color;
import com.omuao.rom.nes.common.model.graphics.impl.ColorImpl;

/**
 * 颜色
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public enum Colors {

    RED(0xFFFF0000),
    GREEN(0xFF00FF00),
    BLUE(0xFF0000FF),
    WHITE(0xFFFFFFFF),
    BLACK(0xFF000000);


    /**
     * 红
     */
    private int r;

    /**
     * 绿
     */
    private int g;

    /**
     * 蓝
     */
    private int b;

    /**
     * 透明度
     */
    private int alpha;

    /**
     * 颜色
     */
    private Color color;

    Colors(int argb) {
        this.color = new ColorImpl();
        this.color.setArgb(argb);
        this.r = this.color.getR();
        this.g = this.color.getG();
        this.b = this.color.getB();
        this.alpha = this.color.getAlpha();
    }

    Colors(int r, int g, int b, int alpha) {
        this.r = r;
        this.g = g;
        this.b = b;
        this.alpha = alpha;
        this.color = new ColorImpl(r, g, b, alpha);
    }

    public int getR() {
        return r;
    }

    public void setR(int r) {
        this.r = r;
    }

    public int getG() {
        return g;
    }

    public void setG(int g) {
        this.g = g;
    }

    public int getB() {
        return b;
    }

    public void setB(int b) {
        this.b = b;
    }

    public int getAlpha() {
        return alpha;
    }

    public void setAlpha(int alpha) {
        this.alpha = alpha;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
