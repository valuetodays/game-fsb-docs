package com.omuao.rom.nes.common.utils;

/**
 * 类工具类
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public class ClassUtils {

    /**
     * 获得简单类名
     *
     * @param clazz
     * @return
     */
    public static String getShortClassName(Class clazz) {
        return clazz.getSimpleName();
    }

}
