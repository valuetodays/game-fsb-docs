package com.omuao.rom.nes.common.model.graphics;

/**
 * 颜色
 *
 * @author yumi@oumao.com
 * @since 2019-07-05
 **/
public interface Color {

    /**
     * 设置红
     *
     * @param r 红
     */
    void setR(int r);

    /**
     * 设置绿
     *
     * @param g 绿
     */
    void setG(int g);

    /**
     * 设置蓝
     *
     * @param b 蓝
     */
    void setB(int b);

    /**
     * 设置透明度
     *
     * @param alpha 透明度
     */
    void setAlpha(int alpha);

    /**
     * 获得红
     *
     * @return 红
     */
    int getR();

    /**
     * 获得绿
     *
     * @return 绿
     */
    int getG();

    /**
     * 获得蓝
     *
     * @return 蓝
     */
    int getB();

    /**
     * 获得 透明度
     *
     * @return 透明度
     */
    int getAlpha();

    /**
     * 获得ARGB值
     *
     * @return ARGB 值
     */
    int getArgb();

    /**
     * 设置ARGB 值
     *
     * @param argb ARGB值
     */
    void setArgb(int argb);
}
