package com.omuao.rom.nes.common.model.instruction;

import java.util.List;
import java.util.Set;

/**
 * 指令集
 *
 * @author yumi@oumao.com
 * @since 2019-09-23
 **/
public interface InstructionSet extends Set {

    /**
     * 获得指令集别名
     *
     * @return 编码别名
     */
    String getAliasName();

    /**
     * 设置指令集别名
     *
     * @param aliasName 指令集别名
     */
    void setAliasName(String aliasName);

    /**
     * 获得指令集
     *
     * @return 指令集
     */
    List<Instruction> getInstructions();

    /**
     * 设置指令集
     *
     * @param instructions 指令集
     */
    void setInstructions(List<Instruction> instructions);

    /**
     * 根据指令编码查找指令
     *
     * @return 指令
     */
    Instruction getInstructionByCode();

}
