package me.herbix.jnes.ppu;

import me.herbix.jnes.cpu.CPU;
import me.herbix.jnes.memory.Memory;
import me.herbix.jnes.screen.Screen;

/**
 * PPU interface.
 * Created by Chaofan on 2017/2/22.
 */
public interface PPU {

    int SCREEN_WIDTH = 256;
    int SCREEN_HEIGHT = 240;

    int VERTICAL_MIRRORING = 0;
    int HORIZONTAL_MIRRORING = 1;
    int ONE_SCREEN_MIRRORING = 2;
    int FOUR_SCREEN_MIRRORING = 3;

    void setCHRMemory(Memory chrRom);
    void setMirroringType(int mirroringType);

    PPURegister getRegister();
    Memory getSprRam();

    void writeRegister(int index, int value);
    int readRegister(int index);

    void cycle(Screen screen, CPU cpu);
    void powerUp();
    void reset();

    boolean inVerticalBlank();

    int getScanline();
    int getCycle();
}
