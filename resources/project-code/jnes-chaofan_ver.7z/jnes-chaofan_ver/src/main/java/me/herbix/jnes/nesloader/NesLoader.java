package me.herbix.jnes.nesloader;

/**
 * Loader interface.
 * Created by Chaofan on 2017/2/22.
 */
public interface NesLoader {
    int getPRGPageCount();
    int getCHRPageCount();
    byte[] getPRGPage(int index);
    byte[] getCHRPage(int index);
    int getMapper();
    boolean isHorizontalMirroring();
    boolean isVerticalMirroring();
    boolean isSRAMEnabled();
    boolean is512ByteTrainerPresent();
    boolean isFourScreenMirroring();
    byte[] getTrainer();
}
