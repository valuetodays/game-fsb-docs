package me.herbix.jnes.cpu;

/**
 * Created by Chaofan on 2017/3/14.
 */
public interface IRQGenerator {
    /**
     * @return false for high, true for low. Low to generate IRQ.
     */
    boolean getIRQLevel();
}
