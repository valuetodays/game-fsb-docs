package me.herbix.jnes.apu;

import me.herbix.jnes.cpu.CPU;

/**
 * Sound generator interface.
 * Created by Chaofan on 2017/3/3.
 */
public interface SoundGenerator {
    void cycle(CPU cpu);
    void setEnabled(boolean enabled);
    void setRegister(int index, int value);
    int output();
    boolean isActive();
    void clockLengthCounterAndSweep();
    void clockEnvelopAndLinearCounter();
}
