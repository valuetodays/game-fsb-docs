package me.herbix.jnes.apu;

import me.herbix.jnes.cpu.CPU;

/**
 * Mute generator. Only for test.
 * Created by Chaofan on 2017/3/5.
 */
public class MuteGenerator implements SoundGenerator {
    public void cycle(CPU cpu) {

    }

    public void setEnabled(boolean enabled) {

    }

    public void setRegister(int index, int value) {

    }

    public int output() {
        return 0;
    }

    public boolean isActive() {
        return false;
    }

    public void clockLengthCounterAndSweep() {

    }

    public void clockEnvelopAndLinearCounter() {

    }
}
