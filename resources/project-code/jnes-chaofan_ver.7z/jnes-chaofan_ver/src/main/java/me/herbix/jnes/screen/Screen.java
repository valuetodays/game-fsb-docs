package me.herbix.jnes.screen;

import java.awt.image.BufferedImage;

/**
 * Output PPU-rendered image to Java BufferedImage type.
 * Created by Chaofan on 2017/2/25.
 */
public interface Screen {
    void set(int x, int y, int color);
    BufferedImage show();
}
