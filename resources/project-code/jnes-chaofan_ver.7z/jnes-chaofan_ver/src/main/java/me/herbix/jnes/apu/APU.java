package me.herbix.jnes.apu;

import me.herbix.jnes.cpu.CPU;
import me.herbix.jnes.cpu.IRQGenerator;
import me.herbix.jnes.speaker.Speaker;

/**
 * APU interface.
 * Created by Chaofan on 2017/2/22.
 */
public interface APU extends IRQGenerator {

    APURegister getRegister();

    void writeRegister(int index, int value);
    int readRegister(int index);

    void cycle(Speaker speaker, CPU cpu);
    void powerUp();
    void reset();
}
