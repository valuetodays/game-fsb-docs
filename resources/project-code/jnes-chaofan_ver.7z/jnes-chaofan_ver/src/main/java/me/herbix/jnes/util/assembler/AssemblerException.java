package me.herbix.jnes.util.assembler;

/**
 * Created by Chaofan on 2017/3/15.
 */
public class AssemblerException extends Exception {
    public AssemblerException(String message) {
        super(message);
    }
    public AssemblerException(String message, Throwable cause) {
        super(message, cause);
    }
    public AssemblerException(Throwable cause) {
        super(cause);
    }
    protected AssemblerException(String message, Throwable cause,
                        boolean enableSuppression,
                        boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
