package me.herbix.jnes.cpu;

import me.herbix.jnes.memory.Memory;

/**
 * CPU interface.
 * Created by Chaofan on 2017/2/22.
 */
public interface CPU {
    void setMemory(Memory memory);
    Memory getMemory();
    long execute();
    CPURegister getRegister();
    long getCycle();
    void increaseCycle(int value);
    void reset();
    void powerUp();
    void nmi();
    void addIRQGenerator(IRQGenerator generator);
}
