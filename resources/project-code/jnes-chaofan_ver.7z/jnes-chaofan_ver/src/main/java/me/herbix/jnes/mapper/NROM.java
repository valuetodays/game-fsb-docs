package me.herbix.jnes.mapper;

import me.herbix.jnes.cpu.CPU;
import me.herbix.jnes.input.Input;
import me.herbix.jnes.memory.CompositeMemory;
import me.herbix.jnes.memory.ReadonlyMemory;
import me.herbix.jnes.nesloader.NesLoader;
import me.herbix.jnes.apu.APU;
import me.herbix.jnes.ppu.PPU;

/**
 * Mapper = 0
 * Created by Chaofan on 2017/3/1.
 */
public class NROM extends Mapper {
    @Override
    public void mapMemoryImpl(CompositeMemory memory, NesLoader loader, CPU cpu, PPU ppu, APU APU, Input input) {
        memory.setMemory(0x8000, new ReadonlyMemory(loader.getPRGPage(0)));
        memory.setMemory(0xC000, new ReadonlyMemory(loader.getPRGPage(loader.getPRGPageCount() - 1)));
    }
}
