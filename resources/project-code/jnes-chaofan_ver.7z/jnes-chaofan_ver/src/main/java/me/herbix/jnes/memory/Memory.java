package me.herbix.jnes.memory;

/**
 * Memory interface.
 * Created by Chaofan on 2017/2/22.
 */
public interface Memory {
    int getSize();
    int getByte(int address);
    void setByte(int address, int value);
}
