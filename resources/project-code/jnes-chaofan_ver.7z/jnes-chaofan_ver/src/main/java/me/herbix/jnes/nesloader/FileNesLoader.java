package me.herbix.jnes.nesloader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * Loads NES file from a file.
 * Created by Chaofan on 2017/2/22.
 */
public class FileNesLoader extends InputStreamNesLoader {
    public FileNesLoader(String filename) throws IOException {
        this(new File(filename));
    }

    public FileNesLoader(File file) throws IOException {
        super(new FileInputStream(file));
    }
}
