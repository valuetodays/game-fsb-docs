package me.herbix.jnes.apu;

/**
 * Created by Chaofan on 2017/3/3.
 */
public interface Divider {
    void setPeriod(int value);
    void setOutputClock(DividerListener outputClock);
    void reset();
    void clock();
    int getValue();
}
