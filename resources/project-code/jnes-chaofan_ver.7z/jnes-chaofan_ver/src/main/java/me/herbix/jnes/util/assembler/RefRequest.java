package me.herbix.jnes.util.assembler;

/**
 * Created by Chaofan on 2017/3/16.
 */
public class RefRequest {
    int line;
    String ref;
    int offset;
    boolean onlyHalf;
    boolean highHalf;
    public RefRequest(int line, int offset, String ref) {
        this.line = line;
        this.ref = ref;
        this.offset = offset;
        this.onlyHalf = false;
    }
    public RefRequest(int line, int offset, String ref, boolean highHalf) {
        this.line = line;
        this.ref = ref;
        this.offset = offset;
        this.highHalf = highHalf;
        this.onlyHalf = true;
    }
}
