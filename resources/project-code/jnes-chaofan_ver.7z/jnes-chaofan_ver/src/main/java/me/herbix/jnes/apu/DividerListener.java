package me.herbix.jnes.apu;

/**
 * Created by Chaofan on 2017/3/3.
 */
public interface DividerListener {
    void onClock(Divider divider);
}
