package me.herbix.jnes.speaker;

/**
 * Output wave from APU signals.
 * Created by Chaofan on 2017/3/3.
 */
public interface Speaker {
    /**
     * @param level from 0 ~ 255
     */
    void set(int level);
    byte[] output();
    void reset();
}
