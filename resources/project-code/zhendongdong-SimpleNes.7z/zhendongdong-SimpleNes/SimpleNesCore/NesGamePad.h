#pragma once
#include "savebundle.h"

class NesGamePad
{
private:
    //D7��ʾ�Ƿ�ѡͨ��0 ѡͨ��1����
    uint8_t mGamepadEn = 0;
    uint8_t mGamepadIndex_1 = 0;
    uint8_t mGamepadIndex_2 = 0;
    uint8_t mGamepadStatus[16] = {0};
public:

    NesGamePad();
    void UserInput(uint8_t index, unsigned state);
    void WriteRegViaCpu(uint16_t address, uint8_t data);
    uint8_t ReadRegViaCpu(uint16_t address);
    void Reset();
    void Save(SaveBundle* bundle);
    void Restore(SaveBundle* bundle);
};

