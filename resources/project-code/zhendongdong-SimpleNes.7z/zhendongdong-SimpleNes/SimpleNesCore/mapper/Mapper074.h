#pragma once

#include "Mapper004.h"

class Mapper074 : public Mapper004 {
public:
    Mapper074(Famicom* fc, famicom_rom_t* rom) :Mapper004(fc, rom) {

	}
};
