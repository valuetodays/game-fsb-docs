#include "Mapper003.h"
void Mapper003::WriteViaPPU(uint16_t address, uint8_t data) {

}

void Mapper003::WriteViaCPU(uint16_t address, uint8_t data) {
    SetPPUBank_8KB(data);
}
