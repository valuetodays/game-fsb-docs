#pragma once

#include "Mapper004.h"
#include "../Rom.h"

class Mapper245 : public Mapper004 {
public:
    Mapper245(Famicom* fc, famicom_rom_t* rom) :Mapper004(fc, rom) {

    }


};
