#include "Mapper001.h"
#include "../Rom.h"
#include "../Famicom.h"
#include "../Devices.h"

/// <summary>
/// ������Ϸ��
/// ˫����1
/// ѩ���ֵ�
/// �������ս 
/// �ж�ս��(����)
/// ��еս��
/// </summary>

void Mapper001::OnReset() {
    //CMapper::Reset();

    mShifter = 0x10;
    mControl = 0;
    mPRGMode = 0;
    mIsCHR8kb = false;


    SetCPUBank_16KB(0, 0);
    SetCPUBank_16KB(1, mROM->prg16kbCount - 1);

    SetPPUBank_4KB(0, 0);
    SetPPUBank_4KB(1, 1);
}

void Mapper001::UpdateControl(uint8_t data) {
    this->mControl = data;
    switch (mControl & 0x3)
    {
    case 0x0:
        famicom->GetDevices()->ppu()->SwitchMirroring(Mirror::SINGLE_SCREEN_LOWER);
        break;
    case 0x1:
        famicom->GetDevices()->ppu()->SwitchMirroring(Mirror::SINGLE_SCREEN_UPPER);
        break;
    case 0x2:
        famicom->GetDevices()->ppu()->SwitchMirroring(Mirror::VERTICAL);
        break;
    case 0x3:
        famicom->GetDevices()->ppu()->SwitchMirroring(Mirror::HORIZONTAL);
        break;
    }

    mPRGMode = (mControl >> 2) & 0x3;
    mIsCHR8kb = !((mControl >> 4) & 0x1);
}

void Mapper001::UpdateChrbank0()
{
    if (mIsCHR8kb)
    {
        //const uint8_t bank = mShifter;//8KBģʽ���֧��16��
        SetPPUBank_4KB(0, mShifter);
        SetPPUBank_4KB(1, mShifter + 1);
    }
    else
        SetPPUBank_4KB(0, mShifter);
}

void Mapper001::UpdateChrbank1()
{
    if (mIsCHR8kb)return; //8Kģʽ���Դ˼Ĵ���
    SetPPUBank_4KB(1, mShifter);
}

void Mapper001::UpdatePrgbank()
{
#if 0
    DebugPrintf("UpdatePrgbank %x %x\n", mPRGMode, mShifter);
#endif

    if (mPRGMode & 0x2)
    {
        if (mPRGMode & 0x1)
        {
            // 16K of Rom at $8000
            SetCPUBank_16KB(0, mShifter);
            SetCPUBank_16KB(1, mROM->prg16kbCount - 1);
        }
        else {
            // 16K of Rom at $C000
            SetCPUBank_16KB(0, 0);
            SetCPUBank_16KB(1, mShifter);
        }
    }
    else {
        // 32K of Rom at $8000
        SetCPUBank_16KB(0, mShifter);
        SetCPUBank_16KB(1, mShifter + 1);
    }
}

void Mapper001::WriteRegister(uint16_t address)
{
    switch ((address & 0x7FFF) >> 13)
    {
    case 0:
        UpdateControl(mShifter);
        break;
    case 1:
        UpdateChrbank0();
        break;
    case 2:
        UpdateChrbank1();
        break;
    case 3:
        UpdatePrgbank();
        break;
    }
}

void Mapper001::WriteViaCPU(uint16_t address, uint8_t data) {

    //������д��ĵ�ַ���ϴβ�ͬʱ��Ҫ����λ�ƼĴ���
    //����ѩ���ֵܵ���Ϸ���������
    if ((address & 0x6000) != (mLastWriteAddr & 0x6000))
    {
        mShifter = 0x10;
        UpdateControl(mControl | 0x0c);
    }

    mLastWriteAddr = address; //�����ַ

    if (data & 0x80) {
        mShifter = 0x10;
        UpdateControl(mControl | 0x0c);
    }
    else {// D7 = 0 -> д��D0����λ�Ĵ���
        const uint8_t finished = mShifter & 1;
        mShifter >>= 1;
        mShifter |= (data & 1) << 4;
        if (finished) {
            WriteRegister(address);
            mShifter = 0x10;
        }
    }
}

void Mapper001::OnSave(SaveBundle *bundle)
{
    bundle->SaveByte(mShifter);
    bundle->SaveByte(mControl);
    bundle->SaveByte(mPRGMode);
    bundle->SaveByte(mIsCHR8kb);
    bundle->SaveWord(mLastWriteAddr);
}

void Mapper001::OnRestore(SaveBundle *bundle)
{
    mShifter = bundle->RestoreByte();
    mControl = bundle->RestoreByte();
    mPRGMode = bundle->RestoreByte();
    mIsCHR8kb = bundle->RestoreByte();
    mLastWriteAddr = bundle->RestoreWord();
}
