﻿#pragma once
#include "Mapper.h"

class Mapper023 :public Mapper
{
	
};