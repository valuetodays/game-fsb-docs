#include "Mapper000.h"
#include "../NesCartridge.h"
#include <assert.h>


void Mapper000::WriteViaCPU(uint16_t address, uint8_t data)
{
    assert(!"ERROR");
}

void Mapper000::Write6000(uint16_t address, uint8_t data)
{
    //assert(!"�ݲ�֧�ֵ��ڴ��ַ");
}

uint8_t Mapper000::Read6000(uint16_t address)
{
    //assert(!"�ݲ�֧�ֵ��ڴ��ַ");
    return 0;
}

void Mapper000::OnSave(SaveBundle *bundle)
{
}

void Mapper000::OnRestore(SaveBundle *bundle)
{

}
