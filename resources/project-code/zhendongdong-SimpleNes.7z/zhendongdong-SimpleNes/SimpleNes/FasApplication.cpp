#include "FasApplication.h"

HINSTANCE FasApplication::mAppInstance = NULL;

FasApplication::FasApplication(HINSTANCE instance)
{
	FasApplication::mAppInstance = instance;
}

FasApplication::~FasApplication()
{
}

int FasApplication::Loop()
{
	//HACCEL hAccelTable = LoadAccelerators(mAppInstance, MAKEINTRESOURCE(IDC_SIMPLENES));
	MSG msg;
	// ����Ϣѭ��:
	while (GetMessage(&msg, nullptr, 0, 0))
	{
		//if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
		//{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
		//}
	}
	return (int)msg.wParam;
}
